<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_motorInfor', function (Blueprint $table) {
            $table->integer('motorID', true);
            $table->string('motorno');
            $table->string('year');
            $table->string('plateNo');
            $table->string('engineNo');
            $table->string('chassisNo');
            $table->string('motorColor');
            $table->string('motorType');
            $table->string('motorModel');
            $table->dateTime('purchaseDate');
            $table->boolean('motorStatus')->default(1);
            $table->integer('compensationPrice');
            $table->integer('totalPurchasePrice');
            $table->string('inputer')->default("NULL");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_motorInfor');
    }
};
