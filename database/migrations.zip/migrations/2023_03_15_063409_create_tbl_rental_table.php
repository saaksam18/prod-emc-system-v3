<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_rental', function (Blueprint $table) {
            $table->integer('rentalID', true);
            $table->integer('rentalCusID')->index('tbl_rental_fk0');
            $table->integer('motorID')->index('tbl_rental_fk1');
            $table->string('transactionType');
            $table->dateTime('rentalDay');
            $table->dateTime('returnDate');
            $table->dateTime('commingDate')->default(NULL)->nullable();
            $table->integer('rentalPeriod');
            $table->integer('price')->default(NULL)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_rental');
    }
};
