<?php
  // Variables
  return [
    "templateName" => "EMC"
  ];
