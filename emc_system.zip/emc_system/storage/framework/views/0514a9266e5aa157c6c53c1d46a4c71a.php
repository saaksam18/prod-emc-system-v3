

<?php $__env->startSection('title', 'Role Management'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap-select-country.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active">Role Management</li>
    </ol>
</nav>
    
<div class="row mb-3">
    <div class="col-lg-12">
        <button type="button" class="btn btn-warning">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                <a class="text-white" href="<?php echo e(route('roles.create')); ?>"> Create New Role</a>
            <?php endif; ?>
        </button>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <h5 class="card-header bg-primary text-white">Roles Management</h5>
            <div class="table-responsive text-nowrap">
                <div class="table-responsive text-nowrap">
                    <div class="ms-3 me-3">
                        
                        <div class="mt-3">
                            <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        
                        <label class="col-form-label">Table Data</label>
                    </div>
                    <?php if(count($roles) > 0): ?>
                        <table class="table table-hover table-bordered text-nowrap">
                            <thead>
                                <tr>
                                    <th style="width: 100px">Actions</th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', 'No.'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', 'Name'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('guard_name', 'Guard Name'));?>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="d-flex justify-content-between gap-1 text-nowrap">
                                        <a class="btn btn-sm btn-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit</a>
                                        <form method="POST" action="<?php echo e(route('roles.destroy', $role->id)); ?>" onsubmit="return confirm('Are you want to delete role <?php echo e($role->name); ?> ?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                Delete
                                            </button>
                                        </form>
                                    </td>
                                    <td><?php echo e($role->id); ?></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td><?php echo e($role->guard_name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <table class="table table-bordered text-nowrap mb-3">
                            <thead>
                                <tr>
                                    <th style="width: 100px">Actions</th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', 'No.'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', 'Name'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('guard_name', 'Guard Name'));?>
                                    </th>
                                </tr>
                            </thead>
                        </table>
                        <p class="text-center">No roles found.</p>
                    <?php endif; ?>
                </div>
                <!-- Basic Pagination -->
                <div class="demo-inline-spacing">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <?php if($roles->currentPage() > 1): ?>
                                    <li class="page-item first">
                                        <a href="roles?page=<?php echo e($roles->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                    </li>
                                <?php endif; ?>
    
                                    <?php for($i = 1; $i <= $roles->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($roles->currentPage() == $i ? 'active' : ''); ?>">
                                            <a class="page-link" href="roles?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>
    
                                <?php if($roles->currentPage() < $roles->lastPage()): ?>
                                    <li class="page-item last">
                                        <a href="roles?page=<?php echo e($roles->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                    </li>
                                <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <!--/ Basic Pagination -->
            </div>
        </div>
    </div>
</div>

<?php echo $roles->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emcmotorbikerental.com/public_html/resources/views/roles/index.blade.php ENDPATH**/ ?>