

<?php $__env->startSection('title', 'Visa Customer Remind'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active">Visa Customers Reminder</li>
    </ol>
  </nav>

  <div class="row">
    <div class="col-md-12">
        <div class="card">
            <h5 class="bg-primary text-white card-header">Visa Customers</h5>
            <div class="table-responsive text-nowrap">
                <div class="ms-3 me-3">
                    
                    <div class="mt-3">
                        <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    
                    <label class="col-form-label">Table Data</label>
                </div>
                <?php if(count($visas) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th class="text-primary">Actions</th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaID', 'No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.gender', 'Gender'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.nationality', 'Nationality'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaType', 'Visa Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expiration Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $visas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-danger">
                                <td>
                                    <form style="display:inline" method="POST" action="<?php echo e(route('visas.reminded', $visa->visaID)); ?>" onsubmit="return confirm('Are you sure customer <?php echo e($visa->customer->CustomerName); ?> is reminded ?');">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-xs">
                                            Remind Now
                                        </button>
                                    </form>
                                </td>
                                <td><?php echo e($i++); ?></td>
                                <td>
                                    <a href="<?php echo e(route('customers.edit',$visa->customerID)); ?>"><?php echo e($visa->customer->CustomerName); ?></a>
                                </td>
                                <td class="text-center">
                                    <?php echo e($visa->customer->gender); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($visa->customer->nationality); ?>

                                </td>
                                <td>
                                    <?php $__currentLoopData = $customer_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($customer_contact->customerID == $visa->customerID): ?>
                                            <li>
                                                <?php echo e($customer_contact->contactType); ?> : <?php echo e($customer_contact->contactDetail); ?>

                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($visa->visaType); ?></td>
                                <td><?php echo e(date('d-M-Y', strtotime($visa->expireDate))); ?></td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($visa->staff_id == $user->id): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($visa->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <!--/ Basic Pagination -->
                <?php else: ?>
                <table class="table table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th class="text-primary">Actions</th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaID', 'No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.gender', 'Gender'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.nationality', 'Nationality'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaType', 'Visa Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expiration Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                </table><br/>
                <p class="text-center">No visa customer found.</p>
            <?php endif; ?>
            </div>

            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($visas->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/visas/reminder?page=<?php echo e($visas->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                        <?php endif; ?>

                                <?php for($i = 1; $i <= $visas->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($visas->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/visas/reminder?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($visas->currentPage() < $visas->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/visas/reminder?page=<?php echo e($visas->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
     </div>
</div>
</div>

<script>
window.onbeforeunload = function() {
localStorage.setItem('scrollPos', document.documentElement.scrollTop);
};

window.onload = function() {
var scrollPos = localStorage.getItem('scrollPos');
if (scrollPos) {
    window.scrollTo(0, scrollPos);
}
};

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/visas/remind.blade.php ENDPATH**/ ?>