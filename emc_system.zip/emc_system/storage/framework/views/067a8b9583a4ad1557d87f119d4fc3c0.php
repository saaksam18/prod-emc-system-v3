

<?php $__env->startSection('title', 'Edit Customer Information'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/js/bootstrap-select-country.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Custom style1 Breadcrumb -->
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('customers.index')); ?>">Customer Information</a>
      </li>
      <li class="breadcrumb-item active">Edit Customer Information</li>
    </ol>
</nav>
      <!--/ Custom style1 Breadcrumb -->

<div class="col-xxl">
    <div class="card mb-4">
        <div class="card-body">
          
          <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          

            <?php echo Form::model($customer, ['method' => 'PUT','route' => ['customers.update', $customer->customerID]]); ?>

            <?php echo csrf_field(); ?>
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="basic-default-name">Customer Name*</label>
                    <div class="input-group">
                        <?php echo Form::text('CustomerName', null, array('class' => 'form-control')); ?>

                    </div>
                  </div>
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Customer Detail*</label>
                    <div class="input-group">
                      <?php echo Form::text('nationality', null, array('class' => 'form-control', 'list' => 'nationality', 'placeholder' => '-- Nationality --' )); ?>

                      <datalist id="nationality">
                        <?php $__currentLoopData = $countriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($country->nationality); ?>"> <?php echo e($country->nationality); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </datalist> 
                      <select id="gender" name="gender" class="form-select">
                        <option value="N/A" <?php echo e($customer->gender == 'N/A' ? 'selected' : ''); ?>>N/A</option>
                        <option value="Male" <?php echo e($customer->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                        <option value="Female" <?php echo e($customer->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                        <option value="In-Between"> <?php echo e($customer->gender == 'In-Between' ? 'selected' : ''); ?>In-Between</option>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                    <div class="input-group">
                      <?php echo Form::textarea('address', null, array('class' => 'form-control', 'rows' => 3)); ?>

                    </div>
                    <label for="exampleFormControlTextarea1" class="form-label">Remark/Comment</label>
                    <div class="input-group">
                      <?php echo Form::textarea('comment', null, array('class' => 'form-control', 'rows' => 1)); ?>

                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-10">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('customers.index')); ?>" style="color: white">View All Customer</a>
                      </button>
                    </div>
                  </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/customers/edit.blade.php ENDPATH**/ ?>