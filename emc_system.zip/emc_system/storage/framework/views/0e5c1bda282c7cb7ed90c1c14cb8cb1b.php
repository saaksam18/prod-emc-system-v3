

<?php $__env->startSection('title', 'Daily Rental'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        <li class="breadcrumb-item active">Daily Rental Transacton</li>
    </ol>
</nav>

<div class="card mb-3">
    <h5 class="card-header bg-primary text-white">Daily Rental Transaction Detail</h5>
    <div class="row">
        <div class="col-lg-4">
            <div class="ms-3 me-3">
                <label class="col-form-label">Filter</label>
                <form action="" method="get">
                    <div class="input-group input-group-merge">
                        <span class="input-group-text">Date</span>
                        <span class="input-group-text" id="basic-addon-search31"><i class="bx bx-search"></i></span>
                        <input class="form-control" type="date" name="created_at" value="<?php echo e(Request::get('created_at')); ?>" id="created_at">
                        <button type="submit" class="btn btn-warning">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-5">
            <div class="card-body">
                <div class="table-responsive text-nowrap">
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <td colspan="2" class="bg-primary text-white">
                                    Rental Transaction
                                </td>
                            </tr>
                            <tr>
                                <td class="text-primary">New Rental</td>
                                <td>
                                    <span class="badge bg-primary text-white"><?php echo e($newRentals); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-primary">Extension</th>
                                <td>
                                    <span class="badge bg-info text-white"><?php echo e($extensions); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-primary">Exchange Motorbike</th>
                                <td>
                                    <span class="badge bg-secondary text-white"><?php echo e($exchangeMotors); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-primary">Exchange Deposit</th>
                                <td>
                                    <span class="badge bg-secondary text-white"><?php echo e($exchangeDeposits); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-primary">Return</th>
                                <td>
                                    <span class="badge bg-danger text-white"><?php echo e($returns); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th colspan="2" class="table-footer fw-bold bg-dark text-white text-end">Total : <?php echo e($totals); ?></th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card-body">
                <div class="table-responsive text-nowrap">
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <td colspan="5" class="bg-primary text-white">
                                    Rental Percentage
                                </td>
                            </tr>
                            <tr>
                                <td class="text-primary text-center">Motorbike Type</td>
                                <td class="text-primary text-center">Total</td>
                                <td class="text-primary text-center">In Stock</td>
                                <td class="text-primary text-center">On Rent</td>
                                <td class="text-primary text-center">% of Rental</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Big Auto</td>
                                <td class="text-center"><?php echo e($bigATs); ?></td>
                                <td class="text-center"><?php echo e($bigATis); ?></td>
                                <td class="text-center"><?php echo e($bigATor); ?></td>
                                <td class="text-center"><?php echo e($totalBigATPercentageFormatted); ?>%</td>
                            </tr>
                            <tr>
                                <td>Auto</td>
                                <td class="text-center"><?php echo e($ats); ?></td>
                                <td class="text-center"><?php echo e($atis); ?></td>
                                <td class="text-center"><?php echo e($ator); ?></td>
                                <td class="text-center"><?php echo e($totalATPercentageFormatted); ?>%</td>
                            </tr>
                            <tr>
                                <td>50cc Auto</td>
                                <td class="text-center"><?php echo e($ccATs); ?></td>
                                <td class="text-center"><?php echo e($ccATis); ?></td>
                                <td class="text-center"><?php echo e($ccATor); ?></td>
                                <td class="text-center"><?php echo e($total50ccATPercentageFormatted); ?>%</td>
                            </tr>
                            <tr>
                                <td>Manual</td>
                                <td class="text-center"><?php echo e($mts); ?></td>
                                <td class="text-center"><?php echo e($mtis); ?></td>
                                <td class="text-center"><?php echo e($mtor); ?></td>
                                <td class="text-center"><?php echo e($totalMTPercentageFormatted); ?>%</td>
                            </tr>
                            <tr class="bg-dark">
                                <th class="text-white text-center">Total</th>
                                <th class="text-white text-center"><?php echo e($totalMotors); ?></th>
                                <th class="text-white text-center"><?php echo e($totalInstock); ?></th>
                                <th class="text-white text-center"><?php echo e($totalOnRent); ?></th>
                                <th class="text-white text-center"><?php echo e($totalPercentageFormatted); ?>%</th>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
</div>
            <div class="ms-3 me-3">
                <label class="col-form-label">Data Table</label>
            </div>
            <div class="table-responsive text-nowrap">
                <?php if(count($rentals) > 0): ?>
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorID', 'Motor No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Deposit'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Payment Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($rental->motorInfor->motorno); ?></td>
                                <td><?php echo e($rental->customer->CustomerName); ?></td>
                                <td>
                                    <?php $__currentLoopData = $customer_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($customer_contact->customerID == $rental->customerID): ?>
                                            <li>
                                                <?php echo e($customer_contact->contactType); ?> : <?php echo e($customer_contact->contactDetail); ?>

                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $rental_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($rental_deposit->rentalID == $rental->rentalID): ?>
                                            <?php if($rental_deposit->currDepositType == 'Money'): ?>
                                                <li>
                                                    <?php echo e($rental_deposit->currDepositType); ?> : $<?php echo e($rental_deposit->currDeposit); ?>

                                                </li>
                                            <?php else: ?>
                                                <li>
                                                    <?php echo e($rental_deposit->currDepositType); ?> : <?php echo e($rental_deposit->currDeposit); ?>

                                                </li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e(date('d-M-Y', strtotime($rental->created_at))); ?></td>
                                <?php if($rental->transactionType == 'New Rental'): ?>
                                    <td>
                                        <span class="badge bg-label-success"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                <?php elseif($rental->transactionType == 'Extension'): ?>
                                <td>
                                    <span class="badge bg-label-info"><?php echo e($rental->transactionType); ?></span>
                                </td>
                                <?php elseif($rental->transactionType == 'Return'): ?>
                                <td>
                                    <span class="badge bg-label-danger">Return</span>
                                </td>
                                <?php elseif($rental->transactionType == '5'): ?>
                                <td>
                                    <span class="badge bg-label-primary">Temp. Return</span>
                                </td>
                                <?php else: ?>
                                <td>
                                    <span class="badge bg-label-primary"><?php echo e($rental->transactionType); ?></span>
                                </td>
                                <?php endif; ?>
                                <td><?php echo e($rental->price); ?>$</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <table class="table table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorID', 'Motor No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Deposit'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Payment Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                            </th>
                        </tr>
                    </thead>
              </table><br/>
              <p class="text-center">No transactions found.</p>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emcmotorbikerental.com/public_html/resources/views/content/reports/rentals/daily-rental.blade.php ENDPATH**/ ?>