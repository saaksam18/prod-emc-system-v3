<?php $__env->startSection('title', 'Motorbike Detail'); ?>

<?php $__env->startSection('content'); ?>


<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('motorbikes.index')); ?>">Motorbikes Management</a>
        </li>
        <li class="breadcrumb-item active">Motorbike Details</li>
    </ol>
</nav>

<div class="row mb-3">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-primary text-white">Motorbike Details</h5>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        
                        <tr>
                            <th class="bg-primary text-white fw-bold">Basic Informations</th>
                            <?php $__currentLoopData = $motorbike_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="fw-bold">Motorbike No.</th>
                                <th class="fw-bold">
                                    <a href="<?php echo e(route('motorbikes.edit', $motorbike->motorID)); ?>"><?php echo e($motorbike->motorno); ?></a>
                                </th>
                                <td colspan="2">
                                    <?php if($motorbike->motorModel > 0): ?>
                                        <tr>
                                            <td>
                                                <th class="fw-bold">Model</th>
                                                <th class="fw-bold">
                                                    <a href="<?php echo e(route('motorbikes.edit', $motorbike->motorID)); ?>"><?php echo e($motorbike->motorModel); ?></a>
                                                </th>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->motorStatus != null): ?>
                                        <tr>
                                            <td>
                                                <th>Status</th>
                                                <?php if($motorbike->motorStatus == 1): ?>
                                                    <td>
                                                        <span class="badge bg-primary text-white">
                                                            In Stock
                                                        </span>
                                                    </td>
                                                <?php elseif($motorbike->motorStatus == 2): ?>
                                                    <td>
                                                        <span class="badge bg-success text-white">
                                                            On Rent
                                                        </span>
                                                    </td>
                                                <?php elseif($motorbike->motorStatus == 3): ?>
                                                    <td>
                                                        <span class="badge bg-danger text-white">
                                                            Sold
                                                        </span>
                                                    </td>
                                                <?php elseif($motorbike->motorStatus == 4): ?>
                                                    <td>
                                                        <span class="badge bg-danger text-white">
                                                            Lost / Stolen
                                                        </span>
                                                    </td>
                                                <?php elseif($motorbike->motorStatus == 5): ?>
                                                    <td>
                                                        <span class="badge bg-primary text-white">
                                                            Temporary Return
                                                        </span>
                                                    </td>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->year > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Year</th>
                                                <td><?php echo e($motorbike->year); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->motorType > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Type</th>
                                                <td><?php echo e($motorbike->motorType); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->motorColor > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Color</th>
                                                <td><?php echo e($motorbike->motorColor); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->plateNo > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Plate No.</th>
                                                <td><?php echo e($motorbike->plateNo); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->compensationPrice > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Compensation Price.</th>
                                                <td>$<?php echo e($motorbike->compensationPrice); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($motorbike->totalPurchasePrice > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Total Purchase Price.</th>
                                                <td>
                                                    <span class="badge bg-danger">$<?php echo e($motorbike->totalPurchasePrice); ?></span>
                                                </td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        

                        
                        <?php if(count($rentals) > 0): ?>
                        <tr>
                            <th class="bg-warning text-white">Rental Information</th>
                            <th class="text-primary fw-bold">Rent To</th>
                            <?php if($trtc > 1): ?>
                                <th class="text-primary fw-bold"><?php echo e($trtc); ?> Customers</th>
                            <?php else: ?>
                                <th class="text-primary fw-bold"><?php echo e($trtc); ?> Customer</th>
                            <?php endif; ?>

                            <td>
                                <?php if($frd != null): ?>
                                    <tr>
                                        <td>
                                            <th>Begin Rental</th>
                                            <td><?php echo e(date('d-M-Y', strtotime($frd))); ?></td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($lrd != null): ?>
                                    <tr>
                                        <td>
                                            <th>Last Return</th>
                                            <td><?php echo e(date('d-M-Y', strtotime($lrd))); ?></td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($tetts != null): ?>
                                    <tr>
                                        <td>
                                            <th>Time of Exchange (To)</th>
                                            <td><?php echo e($tetts); ?></td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($tetfs != null): ?>
                                    <tr>
                                        <td>
                                            <th>Time of Exchange (From)</th>
                                            <td><?php echo e($tetfs); ?></td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($total_in_stock != null): ?>
                                    <tr>
                                        <td>
                                            <th>Total Purchase Period</th>
                                            <td><?php echo e($total_in_stock); ?> Days</td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($tids != null): ?>
                                    <tr>
                                        <td>
                                            <th>Total In Stock Period</th>
                                            <td><?php echo e($tids); ?> Days</td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($tords != null): ?>
                                    <tr>
                                        <td>
                                            <th>Total Rental Period</th>
                                            <td><?php echo e($tords); ?> Days</td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($trp != null): ?>
                                    <tr>
                                        <td>
                                            <th>Total Rental Price</th>
                                            <td>
                                                <span class="badge bg-primary">$<?php echo e($trp); ?></span>
                                            </td>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if($tmp > 0): ?>
                            <tr class="table-primary">
                                <th colspan="2" class="text-center fw-bold">
                                    Total Motorbike Profit
                                </th>
                                <th class="fw-bold">
                                    <?php echo e($tmp); ?>$
                                </th>
                                <td>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr class="table-danger">
                                <th colspan="2" class="text-danger text-center fw-bold">
                                    Total Motorbike Profit
                                </th>
                                <th class="text-danger fw-bold">
                                    <?php echo e($tmp); ?>$
                                </th>
                                <td>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php endif; ?>
                        
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if(count($rentals) > 0): ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-primary text-white">Motorbike Logs</h5>
            
            <form action="" method="GET">
                <div class="ms-3 me-3">
                    <div class="row">
                        <label class="col-form-label">Filter</label>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Customer Name</span>
                                <input name="CustomerName" class="form-control" list="customers" id="CustomerName" value="<?php echo e(Request::get('CustomerName')); ?>" placeholder="Type to search...">
                                <datalist id="customers">
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer->CustomerName); ?>"> <?php echo e($customer->CustomerName); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Status</span>
                                <select class="form-select" name="transactionType" id="transactionType">
                                    <option value="">-- Status --</option>
                                    <?php $__currentLoopData = $rental_tran_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($motorbike->transactionType == 5): ?>
                                            <option value="5" <?php if(Request::get('transactionType') == 5): ?> selected <?php endif; ?>>Temp. Return</option>
                                        <?php elseif($motorbike->transactionType == 3): ?>
                                            <option value="3" <?php if(Request::get('transactionType') == 3): ?> selected <?php endif; ?>>Sold</option>
                                        <?php elseif($motorbike->transactionType == 4): ?>
                                            <option value="4" <?php if(Request::get('transactionType') == 4): ?> selected <?php endif; ?>>Stolen</option>
                                        <?php else: ?>
                                            <option value="<?php echo e($motorbike->transactionType); ?>" <?php if(Request::get('transactionType') == $motorbike->transactionType): ?> selected <?php endif; ?>><?php echo e($motorbike->transactionType); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Rental Date</span>
                                <input class="form-control" type="date" name="rentalDay" value="<?php echo e(Request::get('rentalDay')); ?>" id="rentalDay">
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Return Date</span>
                                <input class="form-control" type="date" name="returnDate" value="<?php echo e(Request::get('returnDate')); ?>" id="returnDate">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="input-group">
                                <button class="btn btn-warning">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="ms-3 me-3">
                <label class="col-lg-12 col-form-label">Table Data</label>
            </div>
            <div class="table-responsive text-nowrap">
                <?php if(count($motorbikes) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('rentalDay', 'Rental Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($motorbike->price > 0): ?>
                            <tr>
                        <?php else: ?>
                            <tr class="table-danger">
                        <?php endif; ?>
                                <td>
                                    <a href="<?php echo e(route('customers.edit', $motorbike->customerID)); ?>"><?php echo e($motorbike->customer->CustomerName); ?></a>
                                </td>
                                <?php if($motorbike->transactionType == 'New Rental'): ?>
                                    <td>
                                        <span class="badge bg-label-success"><?php echo e($motorbike->transactionType); ?></span>
                                    </td>
                                <?php elseif($motorbike->transactionType == 'Extension'): ?>
                                <td>
                                    <span class="badge bg-label-info"><?php echo e($motorbike->transactionType); ?></span>
                                </td>
                                <?php elseif($motorbike->transactionType == '5'): ?>
                                <td>
                                    <span class="badge bg-label-primary">Temp. Return</span>
                                </td>
                                <?php elseif($motorbike->transactionType == 'Return'): ?>
                                <td>
                                    <span class="badge bg-label-danger"><?php echo e($motorbike->transactionType); ?></span>
                                </td>
                                <?php else: ?>
                                <td>
                                    <span class="badge bg-label-primary"><?php echo e($motorbike->transactionType); ?></span>
                                </td>
                                <?php endif; ?>
                                <td><?php echo e(date('d-M-Y', strtotime($motorbike->rentalDay))); ?></td>
                                <td><?php echo e(date('d-M-Y', strtotime($motorbike->returnDate))); ?></td>
                                <?php if($motorbike->new_price > 0): ?>
                                    <td>$ <?php echo e($motorbike->new_price); ?>.00</td>
                                <?php else: ?>
                                    <td class="text-danger">$ <?php echo e($motorbike->new_price); ?>.00</td>
                                <?php endif; ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($motorbike->staff_id == $user->id): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($motorbike->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <table class="table table-hover table-bordered text-nowrap mb-3">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('rentalDay', 'Rental Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                </table>
                <p class="text-center">No motorbikes found.</p>

            <?php endif; ?>
            </div>
            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($motorbikes->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/motorbikes/<?php echo e($motorbike->motorID); ?>?page=<?php echo e($motorbikes->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                            <?php endif; ?>

                                <?php for($i = 1; $i <= $motorbikes->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($motorbikes->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/motorbikes/<?php echo e($motorbike->motorID); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($motorbikes->currentPage() < $motorbikes->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/motorbikes/<?php echo e($motorbike->motorID); ?>?page=<?php echo e($motorbikes->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <!--/ Basic Pagination -->
        </div>
    </div>
</div>
<?php endif; ?>

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emcmotorbikerental.com/public_html/resources/views/content/motorbikes/show.blade.php ENDPATH**/ ?>