

<?php $__env->startSection('title', 'Motorbikes'); ?>

<?php $__env->startSection('content'); ?>
<!-- Custom style1 Breadcrumb -->
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('motorbikes.index')); ?>">Motorbike Stock</a>
      </li>
      <li class="breadcrumb-item active">Edit Motorbike</li>
    </ol>
</nav>
      <!--/ Custom style1 Breadcrumb -->

<div class="col-xxl">
    <div class="card mb-4">
        <div class="card-body">
          
          <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          

            <?php echo Form::model($motorbike, ['method' => 'PUT','route' => ['motorbikes.update', $motorbike->motorID]]); ?>

            <form action="/motorbikes/{motorbike}/update" method="PUT">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="basic-default-company">General Information*</label>

                    <input type="hidden" name="motorID" value="<?php echo e($motorbike->motorID); ?>">

                    <div class="input-group">
                        <span class="input-group-text">Motorbike No.*</span>
                        <?php echo Form::text('motorno', null, array('class' => 'form-control')); ?>

                        <span class="input-group-text">Year*</span>
                        <?php echo Form::text('year', null, array('class' => 'form-control')); ?>

                    </div>
                </div>

                <div class="row mb-3">
                    <div class="input-group">
                        <span class="input-group-text">Plate No.*</span>
                        <?php echo Form::text('plateNo', null, array('class' => 'form-control')); ?>

                        <span class="input-group-text">Engine No.*</span>
                        <?php echo Form::text('engineNo', null, array('class' => 'form-control')); ?>

                    </div>
                </div>

                <div class="row mb-3">
                    <div class="input-group">
                        <span class="input-group-text">Chassis No.*</span>
                        <?php echo Form::text('chassisNo', null, array('class' => 'form-control')); ?>

                        <span class="input-group-text">Motorbike Color*</span>
                        <?php echo Form::text('motorColor', null, array('class' => 'form-control')); ?>

                    </div>
                </div>

                <div class="row mb-3">
                    <div class="input-group">
                      <span class="input-group-text">Motorbike Model*</span>
                      <input class="form-control" name="motorModel" list="datalistOptions" id="exampleDataList" placeholder="" value="<?php echo e($motorbike->motorModel); ?>" required/>
                        <datalist id="datalistOptions">
                          <option value="Honda PCX">
                          <option value="Honda Air Blade">
                          <option value="Honda Click">
                          <option value="Honda Today">
                          <option value="Honda Vision">
                          <option value="Yamaha Fino">
                          <option value="Yamaha Cygnus">
                          <option value="Yamaha Mio">
                          <option value="Suzuki Smash">
                        </datalist>
                        <select class="form-select" name="motorType" aria-label="Default select example">
                          <option value="1" <?php echo e($motorbike->motorType == 1 ? 'selected' : ''); ?>>Big AT</option>
                            <option value="2" <?php echo e($motorbike->motorType == 2 ? 'selected' : ''); ?>>Auto</option>
                            <option value="3" <?php echo e($motorbike->motorType == 3 ? 'selected' : ''); ?>>50cc AT</option>
                            <option value="4" <?php echo e($motorbike->motorType == 4 ? 'selected' : ''); ?>>Manual</option>
                        </select>
                    </div>
                  </div>
        
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="basic-default-company">Operation Information</label>
                    <div class="input-group">
                        <span class="input-group-text">Purchase Date*</span>
                        <?php echo Form::date('purchaseDate', null, array('class' => 'form-control')); ?>

                        
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="input-group">
                        <span class="input-group-text">Compensation Price*</span>
                        <?php echo Form::text('compensationPrice', null, array('class' => 'form-control')); ?>

                        <select class="form-select" name="motorStatus" aria-label="Default select example">
                            <option value="1" <?php echo e($motorbike->motorStatus == 1 ? 'selected' : ''); ?>>In Stock</option>
                            <option value="2" <?php echo e($motorbike->motorStatus == 2 ? 'selected' : ''); ?>>On Rent</option>
                            <option value="3" <?php echo e($motorbike->motorStatus == 3 ? 'selected' : ''); ?>>Sold</option>
                            <option value="4" <?php echo e($motorbike->motorStatus == 4 ? 'selected' : ''); ?>>Stolen / Lost</option>
                        </select>
                    </div>
                  </div>
        
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="basic-default-name">Total Purchase Price*</label>
                    <div class="input-group">
                      <span class="input-group-text">$</span>
                      <?php echo Form::text('totalPurchasePrice', null, array('class' => 'form-control')); ?>

                      <span class="input-group-text">.00</span>
                    </div>
                  </div>

                    <button type="submit" class="btn btn-primary">Update</button>
            </form>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/motorbikes/edit.blade.php ENDPATH**/ ?>