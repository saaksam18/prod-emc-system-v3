<!-- Footer-->
<!-- Basic footer -->
<section id="basic-footer">
  <footer class="footer bg-light">
    <div class="container-fluid d-flex flex-md-row flex-column justify-content-between align-items-md-center gap-1 container-p-x py-3">
      <div>
        <a href="<?php echo e(config('variables.livePreview')); ?>" target="_blank" class="footer-text fw-bolder"><?php echo e(config('variables.templateName')); ?></a> © 2023 - Expat Scooter Rental Service. All rights reserved.
      </div>
    </div>
  </footer>
</section>
<!--/ Basic footer -->
<!--/ Footer-->
<?php /**PATH /Users/saak/EMC/emc_system/resources/views/layouts/sections/footer/footer.blade.php ENDPATH**/ ?>