
<?php if(session()->has('success')): ?>
<div class="col-lg-12">
    <div class="alert alert-primary " role="alert">
        <?php echo e(session()->get('success')); ?>

    </div>
</div>
<?php endif; ?>
<?php if(count($errors) > 0): ?><div class="col-lg-12">
    <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <span class="badge bg-danger text-white" onclick="this.parentElement.style.display='none';">x</span>
        <br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/BitBucket/EMC_System/resources/views/layouts/sections/messages.blade.php ENDPATH**/ ?>