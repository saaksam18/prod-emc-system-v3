

<?php $__env->startSection('title', 'Exchange Motorbike'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active">Exchange Motorbike</li>
    </ol>
  </nav>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <h5 class="card-header bg-primary text-white">Exchange Motorbikes</h5>
                
                <form action="" method="GET">
                    <div class="ms-3 me-3">
                        <div class="row">
                            <label class="col-form-label">Filter</label>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Customer Name</span>
                                    <input name="CustomerName" class="form-control" list="customer_name" id="CustomerName" value="<?php echo e(Request::get('CustomerName')); ?>" placeholder="Type to search...">
                                    <datalist id="customer_name">
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->CustomerName); ?>"> <?php echo e($customer->CustomerName); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Pre. Motorbike</span>
                                    <input name="preMotorID" class="form-control" list="preMotorID_list" id="preMotorID" value="<?php echo e(Request::get('preMotorID')); ?>" placeholder="Type to search...">
                                    <datalist id="preMotorID_list">
                                        <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorbike->motorno); ?>"> <?php echo e($motorbike->motorno); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">New Motorbike</span>
                                    <input name="currMotorID" class="form-control" list="currMotorID_list" id="currMotorID" value="<?php echo e(Request::get('currMotorID')); ?>" placeholder="Type to search...">
                                    <datalist id="currMotorID_list">
                                        <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorbike->motorno); ?>"> <?php echo e($motorbike->motorno); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Exchange Date</span>
                                    <input type="date" name="changeDate" class="form-control" id="changeDate" value="<?php echo e(Request::get('changeDate')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    </select>
                                    <button class="btn btn-warning">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                
                <div class="table-responsive text-nowrap">
                    <div class="ms-3 me-3">
                        
                        <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                        <label class="col-form-label">Table Data</label>
                    </div>
                    <?php if(count($exchanges) > 0): ?>
                    <table class="table table-hover table-bordered text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('preMotoID', 'Last No.'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('currMotorID', 'Current No.'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Exchange Date'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharge Staff'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('comment', 'Comment'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $exchanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchangeMotor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('customers.edit',$exchangeMotor->customerID)); ?>"><?php echo e($exchangeMotor->customer->CustomerName); ?></a>
                                </td>
                                <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($exchangeMotor->preMotoID == $motorbike->motorID): ?>
                                        <td class="text-center"><?php echo e($motorbike->motorno); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($exchangeMotor->currMotorID == $motorbike->motorID): ?>
                                        <td class="text-center"><?php echo e($motorbike->motorno); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e(date('d-M-Y', strtotime($exchangeMotor->created_at))); ?></td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($exchangeMotor->staff_id == $user->id): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <span><?php echo e($exchangeMotor->comment); ?></span>
                                </td>
                                <td>
                                    <span><?php echo e($exchangeMotor->user->name); ?></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <table class="table table-bordered text-nowrap">
                      <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('preMotoID', 'Previous Motor No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('currMotorID', 'New Motor No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Exchange Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('comment', 'Comment'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharge Staff'));?>
                            </th>
                            <th class="text-primary">
                                Inputer
                            </th>
                        </tr>
                      </thead>
                  </table><br/>
                  <p class="text-center">No transactions found.</p>
                <?php endif; ?>
                </div>
                <!-- Basic Pagination -->
                <div class="demo-inline-spacing">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <?php if($exchanges->currentPage() > 1): ?>
                                    <li class="page-item first">
                                        <a href="/rentals-report/exchange-motor?page=<?php echo e($exchanges->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                    </li>
                            <?php endif; ?>

                                    <?php for($i = 1; $i <= $exchanges->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($exchanges->currentPage() == $i ? 'active' : ''); ?>">
                                            <a class="page-link" href="/rentals-report/exchange-motor?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                <?php if($exchanges->currentPage() < $exchanges->lastPage()): ?>
                                    <li class="page-item last">
                                        <a href="/rentals-report/exchange-motor?page=<?php echo e($exchanges->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                    </li>
                                <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <!--/ Basic Pagination -->
            </div>
         </div>
    </div>
  </div>
  
<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/rentals/exchanges/index.blade.php ENDPATH**/ ?>