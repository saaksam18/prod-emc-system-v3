

<?php $__env->startSection('title', 'WP Customer'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active">All Work Permit Customers</li>
    </ol>
  </nav>
  <div class="row">
    <div class="col-sm-10">
      <button type="button" class="btn btn-warning">
        <a href="<?php echo e(route('work-permit.create')); ?>" style="color: white">Add WP Customers</a>
      </button>
    </div>
  </div>
  <br/>

  <div class="row">
    <div class="col-md-12">
        <div class="card">
            
            <form action="" method="GET">
                <div class="ms-3 me-3">
                    <div class="row">
                        <label class="col-form-label">Filter</label>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Customer Name</span>
                                <input name="CustomerName" class="form-control" list="customer_name" id="CustomerName" value="<?php echo e(Request::get('CustomerName')); ?>" placeholder="Type to search...">
                                <datalist id="customer_name">
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer->CustomerName); ?>"> <?php echo e($customer->CustomerName); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Nationality</span>
                                <input name="nationality" class="form-control" list="nationality_list" id="nationality" value="<?php echo e(Request::get('nationality')); ?>" placeholder="Type to search...">
                                <datalist id="nationality_list">
                                    <?php $__currentLoopData = $countriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->nationality); ?>"> <?php echo e($country->nationality); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <select class="form-select" name="contactType" id="contactType">
                                    <option value="">Contact Type</option>
                                    <?php $__currentLoopData = $customer_contact_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact_ty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer_contact_ty->contactType); ?>" <?php if(Request::get('contactType') == $customer_contact_ty->contactType): ?> selected <?php endif; ?>><?php echo e($customer_contact_ty->contactType); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input name="contactDetail" class="form-control" list="contactD_list" id="contactDetail" value="<?php echo e(Request::get('contactDetail')); ?>" placeholder="Type to search...">
                                <datalist id="contactD_list">
                                    <?php $__currentLoopData = $customer_contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rental->contactDetail); ?>"> <?php echo e($rental->contactDetail); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <select class="form-select" name="gender" id="gender">
                                    <option value="">-- Select Gender --</option>
                                    <?php $__currentLoopData = $customer_gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gender->gender); ?>" <?php if(Request::get('gender') == $gender->gender): ?> selected <?php endif; ?>><?php echo e($gender->gender); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button class="btn btn-warning">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="table-responsive text-nowrap">
                <div class="ms-3 me-3">
                    
                    <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <label class="col-form-label">Table Data</label>
                </div>
                <?php if(count($wps) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th class="text-primary">Actions</th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('wpID', 'No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.gender', 'Gender'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.nationality', 'Nationality'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expiration Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $wps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($wp->wpRemindDate <= now()): ?>
                            <?php if($wp->is_Active == 1): ?>
                                <tr class="table-danger">
                            <?php endif; ?>
                        <?php else: ?>
                            <tr>
                        <?php endif; ?>
                                <td class="text-center">
                                    <?php echo Form::open(['method' => 'get','route' => ['work-permit.edit', $wp->wpID],'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Edit', ['class' => 'btn btn-info btn-xs']); ?>

                                    <?php echo Form::close(); ?>

                                    <form style="display:inline" method="POST" action="<?php echo e(route('work-permit.delete', $wp->wpID)); ?>" onsubmit="return confirm('Are you sure? You want to delete customer <?php echo e($wp->customer->CustomerName); ?> !!!');">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-xs">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                                <td><?php echo e($wp->wpID); ?></td>
                                <td>
                                    <a href="<?php echo e(route('wps.wpShow',$wp->wpID)); ?>"><?php echo e($wp->customer->CustomerName); ?></a>
                                </td>
                                <td class="text-center">
                                    <?php echo e($wp->customer->gender); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($wp->customer->nationality); ?>

                                </td>
                                <td>
                                    <?php $__currentLoopData = $customer_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($customer_contact->customerID == $wp->customerID): ?>
                                            <a href="<?php echo e(route('contacts.edit', $wp->customerID)); ?>">
                                                <li>
                                                    <?php echo e($customer_contact->contactType); ?> : <?php echo e($customer_contact->contactDetail); ?>

                                                </li>
                                            </a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e(date('d-M-Y', strtotime($wp->wpExpireDate))); ?></td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($wp->staff_id == $user->id): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($wp->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <!--/ Basic Pagination -->
                <?php else: ?>
                <table class="table table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th class="text-primary">Actions</th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('wpID', 'No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.gender', 'Gender'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.nationality', 'Nationality'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expiration Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                </table><br/>
                <p class="text-center">No work permit customer found.</p>
            <?php endif; ?>
            </div>

            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($wps->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/work-permit?page=<?php echo e($wps->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                        <?php endif; ?>

                                <?php for($i = 1; $i <= $wps->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($wps->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/work-permit?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($wps->currentPage() < $wps->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/work-permit?page=<?php echo e($wps->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
     </div>
</div>
</div>

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/wps/index.blade.php ENDPATH**/ ?>