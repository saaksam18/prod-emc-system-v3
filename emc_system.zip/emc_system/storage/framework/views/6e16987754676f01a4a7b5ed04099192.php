

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-8 mb-4 order-0">
    <div class="card">
      <div class="d-flex align-items-end row">
        <div class="col-sm-7">
          <div class="card-body">
            <h5 class="card-title text-primary">Welcome to the System! Dashboard 2.0🎉</h5>
            <p class="mb-4">Waiting for you instruction. <span class="fw-bold">New Customer?</span> Click the button</p>

            <a href="<?php echo e(route('rentals.index')); ?>" class="btn btn-sm btn-outline-primary">Manage Rental</a>
          </div>
        </div>
        <div class="col-sm-5 text-center text-sm-left">
          <div class="card-body pb-0 px-0 px-md-4">
            <img src="<?php echo e(asset('assets/img/illustrations/man-with-laptop-light.png')); ?>" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png">
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-4 order-1">
    <div class="row mb-4">
      <div class="col-lg-6 col-md-12 col-6">
        <div class="card">
          <div class="card-body">
            <span class="fw-semibold d-block mb-2">Visa Reminder</span>
            <h4 class="card-title"><?php echo e($totalCustomers); ?></h4>
            <h6 class="mb-3">Customers</h6>
            <a class="btn btn-sm btn-outline-danger" href="<?php echo e(route('visa.reminder')); ?>">View More</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-12 col-6">
        <div class="card">
          <div class="card-body">
            <span class="fw-semibold d-block mb-2">WP Remindrer</span>
            <h4 class="card-title"><?php echo e($totalWPCustomers); ?></h4>
            <h6 class="mb-3">Customers</h6>
              <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('work-permit.reminder')); ?>">View More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Monthly Rental -->
  <div class="col-12 col-lg-8 order-2 order-md-3 order-lg-2 mb-4">
    <div class="card">
      <div class="row row-bordered g-0">
        <div class="col-md-12">
          <h5 class="card-header m-0 me-2 pb-3">Yearly Rental</h5>
          <div id="YearlyChart"></div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Monthly Rental -->
  <div class="col-12 col-md-8 col-lg-4 order-3 order-md-2">
    <div class="row">
      <div class="col-6 mb-4">
        <div class="card">
          <div class="card-body">
            <div class="card-title d-flex align-items-start justify-content-between">
              <div class="avatar flex-shrink-0">
                <img src="<?php echo e(asset('assets/img/icons/unicons/paypal.png')); ?>" alt="Credit Card" class="rounded">
              </div>
            </div>
            <span class="d-block mb-1">Total Cash Deposit</span>
            <h3 class="card-title text-nowrap mb-2">$<?php echo e($countCashs); ?></h3>
            
          </div>
        </div>
      </div>
      <div class="col-6 mb-4">
        <div class="card">
          <div class="card-body">
            <div class="card-title d-flex align-items-start justify-content-between">
              <div class="avatar flex-shrink-0">
                <img src="<?php echo e(asset('assets/img/icons/unicons/cc-primary.png')); ?>" alt="Credit Card" class="rounded">
              </div>
            </div>
            <span class="fw-semibold d-block mb-1">Total Passport Deposit</span>
            <h3 class="card-title mb-2"><?php echo e($countPPs); ?></h3>
            
          </div>
        </div>
      </div>

      
      <div class="col-12 mb-3">
        <div class="card">
          <div class="card-body">
                <div class="card-title">
                <h5 class="text-nowrap mt-1">Motorbikes</h5>
                <div class="row">
                  <div class="col-4">
                    <span class="badge bg-label-warning rounded-pill mt-3">In Stock</span>
                      <h6 class="mb-0 mt-1"><?php echo e($totalInstock); ?> Scooters</h6>
                  </div>
                  <div class="col-4">
                    <span class="badge bg-label-success rounded-pill mt-3">On Rent</span>
                      <h6 class="mb-0 mt-1"><?php echo e($totalOnRent); ?> Scooters</h6>
                  </div>
                  <div class="col-4">
                    <span class="badge bg-label-primary rounded-pill mt-3">Total</span>
                      <h6 class="mb-0 mt-1"><?php echo e($totalMotors); ?> Scooters</h6>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


  <!-- Customer Late Payment -->
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <h5 class="card-header">Customer Late Payment</h5>
      <div class="ms-3 me-3">
          
          <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
      </div>
      <div class="table-responsive text-nowrap">
        <table class="table table-hover table-bordered">
          <?php if(count($rentals) > 0): ?>
          <table class="table table-hover table-bordered text-nowrap">
            <thead>
                <tr>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorno', 'Motor No.'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.gender', 'Gender'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Deposit'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('commingDate', 'Comming Date'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('remainingDays', 'Late Day'));?>
                    </th>
                    <th>
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                    </th>
                </tr>
            </thead>
          <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="table-danger">
                      <td>
                        <a href="<?php echo e(route('rentals.add-coming-date',$rental->rentalID)); ?>"><?php echo e($rental->customer->CustomerName); ?></a>
                      </td>
                      <td class="text-center">
                          <a href="<?php echo e(route('rentals.changeMotorEdit',$rental->rentalID)); ?>"><?php echo e($rental->motorInfor->motorno); ?></a>
                      </td>
                      <td><?php echo e($rental->customer->gender); ?></td>
                      <td>
                          <a href="<?php echo e(route('rentals.exchange-deposit', $rental->rentalID)); ?>">
                              <?php $__currentLoopData = $rental_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($rental_deposit->rentalID == $rental->rentalID): ?>
                                      <?php if($rental_deposit->customerID == $rental->customerID): ?>
                                          <?php if($rental_deposit->currDepositType == 'Money'): ?>
                                              <li>
                                                  <?php echo e($rental_deposit->currDepositType); ?> : $<?php echo e($rental_deposit->currDeposit); ?>

                                              </li>
                                          <?php else: ?>
                                              <li>
                                                  <?php echo e($rental_deposit->currDepositType); ?> : <?php echo e($rental_deposit->currDeposit); ?>

                                              </li>
                                          <?php endif; ?>
                                      <?php else: ?>
                                              <li>Add Deposit</li>
                                      <?php endif; ?>
                                  <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </a>
                      </td>
                      <td>
                          <?php $__currentLoopData = $customer_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($customer_contact->customerID == $rental->customerID): ?>
                                  <a href="<?php echo e(route('contacts.edit', $customer_contact->customerID)); ?>">
                                      <li>
                                          <?php echo e($customer_contact->contactType); ?> : <?php echo e($customer_contact->contactDetail); ?>

                                      </li>
                                  </a>
                              <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </td>
                        <td><?php echo e(date('d-M-Y', strtotime($rental->returnDate))); ?></td>
                      <?php if($rental->commingDate != null): ?>
                        <td><?php echo e(date('d-M-Y', strtotime($rental->commingDate))); ?></td>
                      <?php else: ?>
                        <td>No Data</td>
                      <?php endif; ?>
                      <td>- <?php echo e($rental->remainingDays); ?> Days</td>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($rental->staff_id == $user->id): ?>
                              <td><?php echo e($user->name); ?></td>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
        <!--/ Basic Pagination -->
        <?php else: ?>
        <table class="table table-bordered text-nowrap">
            <thead>
              <tr>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorno', 'Motor No.'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.gender', 'Gender'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Deposit'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('commingDate', 'Comming Date'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('remainingDays', 'Late Day'));?>
                  </th>
                  <th>
                      <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                  </th>
              </tr>
            </thead>
      </table><br/>
      <p class="text-center">No transactions found.</p>
    <?php endif; ?>
      </div>
      <!-- Basic Pagination -->
      <div class="demo-inline-spacing">
          <nav aria-label="Page navigation">
              <ul class="pagination justify-content-end">
                  <?php if($rentals->currentPage() > 1): ?>
                          <li class="page-item first">
                              <a href="/home?page=<?php echo e($rentals->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                          </li>
                  <?php endif; ?>
                          <?php for($i = 1; $i <= $rentals->lastPage(); $i++): ?>
                              <li class="page-item <?php echo e($rentals->currentPage() == $i ? 'active' : ''); ?>">
                                  <a class="page-link" href="/home?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                              </li>
                          <?php endfor; ?>

                      <?php if($rentals->currentPage() < $rentals->lastPage()): ?>
                          <li class="page-item last">
                              <a href="/home?page=<?php echo e($rentals->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                          </li>
                      <?php endif; ?>
              </ul>
          </nav>
      </div>
    </div>
  </div>
</div>
<!--/ Contextual Classes -->

<script>
  var options = {
          series: [{
          data: <?php echo json_encode($yearData['data']); ?>

        }],
          chart: {
          type: 'bar',
          height: 300
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        colors: [config.colors.primary, config.colors.info],
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: <?php echo json_encode($yearData['categories']); ?>,
        },
        yaxis: {
          title: {
            text: 'New Rental Motorbikes'
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
              return val + " motorbikes"
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#YearlyChart"), options);
        chart.render();
</script>

<script>
  window.onbeforeunload = function() {
  localStorage.setItem('scrollPos', document.documentElement.scrollTop);
  };

  window.onload = function() {
  var scrollPos = localStorage.getItem('scrollPos');
  if (scrollPos) {
      window.scrollTo(0, scrollPos);
  }
  };

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/dashboard/dashboards-analytics.blade.php ENDPATH**/ ?>