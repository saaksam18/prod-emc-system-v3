

<?php $__env->startSection('title', 'Exchange Motorbike'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb breadcrumb-style1">
    <li class="breadcrumb-item">
      <a href="<?php echo e(route('home')); ?>">Home</a>
    </li>
    <li class="breadcrumb-item">
      <a href="<?php echo e(route('rentals.index')); ?>">Rental Management</a>
    </li>
    <li class="breadcrumb-item active">Exchange Motorbike</li>
  </ol>
</nav>
  <div class="col-lg-12">
    <div class="card mb-4">
      <div class="card-body">
        
        <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo Form::model($rental, ['method' => 'put','route' => ['rentals.exchange-motor', $rental->rentalID]]); ?>

        <?php echo csrf_field(); ?>
        <?php echo Form::hidden('rentalID', null, array('class' => 'form-control')); ?>

        <label class="col-sm-2 col-form-label" for="basic-default-name">Customer Name</label>
        <div class="input-group mb-3">
          <select id="customer" name="customerID" class="form-control" data-live-search="true" disabled> 
            <option selected>-- Select Customer --</option>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($customer->customerID); ?>" <?php echo e($customer->customerID == $rental->customerID ? 'selected' : ''); ?>><?php echo e($customer->CustomerName); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <input type="hidden" class="form-control" name="customerID" id="customerID" value="<?php echo e($customer->customerID); ?>" />
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 col-form-label" for="basic-default-company">Previous Motorbike</label>
          <div class="input-group">
            <span class="input-group-text">Motorbike No.</span>
            <select id="motorID" name="motorID" class="form-control" disabled> 
              <option selected>-- Select Motorbike --</option>
              <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($motorbike->motorID); ?>" <?php echo e($motorbike->motorID == $rental->motorID ? 'selected' : ''); ?>><?php echo e($motorbike->motorno); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="hidden" class="form-control" name="oldMotorbikeID" id="oldMotorbikeID" value="<?php echo e($rental->motorID); ?>" />
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 col-form-label" for="basic-default-company">New Motorbike</label>
          <div class="input-group">
            <span class="input-group-text">Motorbike No.</span>
            <select id="motorID" name="motorID" class="form-control select2">
                <option selected>-- Select Motrobike --</option>
                <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($motorbike->motorStatus == '1'): ?>
                    <option value="<?php echo e($motorbike->motorID); ?>"><?php echo e($motorbike->motorno); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="row mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Remark/Comment</label>
          <div class="input-group">
            <?php echo Form::textarea('comment', null, array('class' => 'form-control', 'rows' => 3)); ?>

          </div>
        </div>
        <div class="row mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Staff Incharge</label>
          <div class="input-group">
            <select class="form-select" name="staffId" aria-label="staffId">
              <option value="">-- Staff Incharge --</option>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $rental->staff_id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-10">
            <button type="submit" class="btn btn-warning">Save</button>
          </div>
        </div>
        <?php echo Form::close(); ?>

      </div>
  </div>
</div>

<script type="text/javascript">
  function GetDays(){
          var returnDate = new Date(document.getElementById("return_date").value);
          var rentalDate = new Date(document.getElementById("rental_date").value);
          return parseInt((returnDate - rentalDate) / (24 * 3600 * 1000));
  }

  function cal(){
  if(document.getElementById("return_date")){
      document.getElementById("peroidOfRent").value=GetDays();
  }  
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emcmotorbikerental.com/public_html/resources/views/content/rentals/exchanges/edit.blade.php ENDPATH**/ ?>