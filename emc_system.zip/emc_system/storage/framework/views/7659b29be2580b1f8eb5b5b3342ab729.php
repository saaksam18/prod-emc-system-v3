<style>
    .container {
        width: 100%;
        display: flex;
        /* Aligns the tables horizontally side-by-side */
        flex-direction: row;
        /* Prevents wrapping to a new line if space is limited */
        flex-wrap: nowrap;
        /* Optional: add space between tables */
        gap: 10px;
        }
    .container-1 {
    width: 50%;
    display: flex;
    /* Aligns the tables horizontally side-by-side */
    flex-direction: column;
    /* Optional: add space between tables */
    gap: 10px;
    }
    .table1, .table2 {
        /* Makes each table flexible and takes up equal space */
        flex: 2;
        padding: 10px;
        }
    table {
        border: 1px solid #DDD;
        border-collapse: collapse;
        }
    th{
            color: #083763;
        }
    th, td {
        padding: 8px;
        text-align: left;
        border: 1px solid #DDD;
        }

        tr:hover {background-color: #D6EEEE;}
</style>
    <div class="container">
        <table class="table1">
            <thead>
                <tr>
                    <th>
                        No.
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Model
                    </th>
                    <th>
                        Type
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($motorbike->motorno); ?></td>
                    <?php if($motorbike->motorStatus == 1): ?>
                    <td>
                        <span class="badge bg-primary text-white">
                            In Stock
                        </span>
                    </td>
                    <?php elseif($motorbike->motorStatus == 2): ?>
                    <td>
                        <span class="badge bg-success text-white">
                            On Rent
                        </span>
                    </td>
                    <?php elseif($motorbike->motorStatus == 3): ?>
                    <td>
                        <span class="badge bg-danger text-white">
                            Sold
                        </span>
                    </td>
                    <?php elseif($motorbike->motorStatus == 4): ?>
                    <td>
                        <span class="badge bg-danger text-white">
                            Lost / Stolen
                        </span>
                    </td>
                    <?php elseif($motorbike->motorStatus == 5): ?>
                    <td>
                        <span class="badge bg-primary text-white">
                            Temporary Return
                        </span>
                    </td>
                    <?php endif; ?>
                    <td><?php echo e($motorbike->motorModel); ?></td>
                    <?php if($motorbike->motorType == 1): ?>
                        <td>Big AT</td>
                    <?php elseif($motorbike->motorType == 2): ?>
                        <td>Auto</td>
                    <?php elseif($motorbike->motorType == 3): ?>
                        <td>50cc AT</td>
                        <?php elseif($motorbike->motorType == 4): ?>
                        <td>Manual</td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="container-1">
            <table class="table2">
                <thead>
                    <tr>
                        <td>Motorbike Type</td>
                        <td>Total In Stock</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Big Auto</td>
                        <td class="text-center">
                            <?php echo e($bigATis); ?>  <?php if($tempBigATis != NULL): ?>
                                (TM Return: <?php echo e($tempBigATis); ?>)
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Auto</td>
                        <td class="text-center">
                            <?php echo e($atis); ?>  <?php if($tempATis != NULL): ?>
                            (TM Return: <?php echo e($tempATis); ?>)
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>50cc Auto</td>
                        <td class="text-center">
                            <?php echo e($ccATis); ?>  <?php if($tempCCATis != NULL): ?>
                            (TM Return: <?php echo e($tempCCATis); ?>)
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Manual</td>
                        <td class="text-center">
                            <?php echo e($mtis); ?>  <?php if($tempMTis != NULL): ?>
                            (TM Return: <?php echo e($tempMTis); ?>)
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="bg-dark">
                        <td class="text-white text-center">Total</td>
                        <td class="text-white text-center"><?php echo e($totalInstock); ?></td>
                    </tr>
                </tbody>
            </table>
            <table class="table2">
                <thead>
                    <tr>
                        <td>Motorbike Model</td>
                        <td>Total In Stock (Include TM Return)</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $motorbikeCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbikeCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($motorbikeCount->motorModel); ?></td>
                            <td><?php echo e($motorbikeCount->total_count); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr style="font-weight: bold; color: #083763">
                            <td>Total In Stock</td>
                            <td><?php echo e($motorbikeTotalCounts); ?></td>
                        </tr>
                </tbody>
            </table>
    </div>
    </div><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/motorbikes/print.blade.php ENDPATH**/ ?>