

<?php $__env->startSection('title', 'Motorbikes Management'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        <li class="breadcrumb-item active">Motorbikes Management</li>
    </ol>
</nav>

<div class="row mb-3">
    <div class="col-lg-12">
        <button type="button" class="btn btn-warning">
        <a href="<?php echo e(route('motorbikes.create')); ?>" style="color: white">Create New Motorbike</a>
        </button>
        <button type="button" class="btn btn-dark">
        <a href="<?php echo e(route('print-stock')); ?>" style="color: white">Print Stock</a>
        </button>
    </div>
</div>
    

<div class="row">
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="">
                <div class="table-responsive text-nowrap">
                    <table class="table table-hover table-bordered">
                        <thead class="bg-primary">
                            <tr>
                                <td class="text-white text-center">Type</td>
                                <td class="text-white text-center">Total</td>
                                <td class="text-white text-center">In Stock</td>
                                <td class="text-white text-center">On Rent</td>
                                <td class="text-white text-center">% of Rental</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Big Auto</td>
                                <td class="text-center"><?php echo e($bigATs); ?></td>
                                <td class="text-center">
                                    <?php echo e($bigATis); ?>  <?php if($tempBigATis != NULL): ?>
                                        (TM Return: <?php echo e($tempBigATis); ?>)
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($bigATor); ?></td>
                                <td class="text-center"><?php echo e($totalBigATPercentageFormatted); ?>%</td>
                            </tr>
                            <tr>
                                <td>Auto</td>
                                <td class="text-center"><?php echo e($ats); ?></td>
                                <td class="text-center">
                                    <?php echo e($atis); ?>  <?php if($tempATis != NULL): ?>
                                    (TM Return: <?php echo e($tempATis); ?>)
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($ator); ?></td>
                                <td class="text-center"><?php echo e($totalATPercentageFormatted); ?>%</td>
                            </tr>
                            <tr>
                                <td>50cc Auto</td>
                                <td class="text-center"><?php echo e($ccATs); ?></td>
                                <td class="text-center">
                                    <?php echo e($ccATis); ?>  <?php if($tempCCATis != NULL): ?>
                                    (TM Return: <?php echo e($tempCCATis); ?>)
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($ccATor); ?></td>
                                <td class="text-center"><?php echo e($total50ccATPercentageFormatted); ?>%</td>
                            </tr>
                            <tr>
                                <td>Manual</td>
                                <td class="text-center"><?php echo e($mts); ?></td>
                                <td class="text-center">
                                    <?php echo e($mtis); ?>  <?php if($tempMTis != NULL): ?>
                                    (TM Return: <?php echo e($tempMTis); ?>)
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($mtor); ?></td>
                                <td class="text-center"><?php echo e($totalMTPercentageFormatted); ?>%</td>
                            </tr>
                            <tr class="bg-dark">
                                <td class="text-white text-center">Total</td>
                                <td class="text-white text-center"><?php echo e($totalMotors); ?></td>
                                <td class="text-white text-center"><?php echo e($totalInstock); ?></td>
                                <td class="text-white text-center"><?php echo e($totalOnRent); ?></td>
                                <td class="text-white text-center"><?php echo e($totalPercentageFormatted); ?>%</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card mb-4">
            <div class="p-2 text-center">
                <div class="card-title">
                    <h5 class="text-nowrap mt-1 text-start ms-2">Motorbikes</h5>
                    <div class="row">
                        <div class="col-3">
                            <span class="badge bg-label-warning rounded-pill mt-1">In Stock</span>
                            <h6 class="mb-0 mt-1"><?php echo e($totalInstock); ?></h6>
                        </div>
                        <div class="col-3">
                            <span class="badge bg-label-success rounded-pill mt-1">On Rent</span>
                            <h6 class="mb-0 mt-1"><?php echo e($totalOnRent); ?></h6>
                        </div>
                        <div class="col-3">
                            <span class="badge bg-label-primary rounded-pill mt-1">Temp. In Stock</span>
                            <h6 class="mb-0 mt-1"><?php echo e($tempReturn); ?></h6>
                        </div>
                        <div class="col-3">
                            <span class="badge bg-primary rounded-pill mt-1 ps-3 pe-3">Total</span>
                            <h6 class="mb-0 mt-1"><?php echo e($totalMotors); ?></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-3">
            <div class="p-2 text-center">
                <div class="card-title">
                    <h5 class="text-nowrap mt-1 text-start ms-2">Today Transactions</h5>
                    <div class="row">
                        <div class="col-6">
                            <span class="badge bg-success rounded-pill mt-1">Rent</span>
                            <h6 class="mb-0 mt-1"><?php echo e($rent_today); ?> Scooters</h6>
                        </div>
                        <div class="col-6">
                            <span class="badge bg-danger rounded-pill mt-1">Return</span>
                            <h6 class="mb-0 mt-1"><?php echo e($return_today); ?> Scooters</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-primary text-white">Motorbike Informations</h5>
            
            <form action="" method="GET">
                <div class="ms-3 me-3">
                    <div class="row">
                        <label class="col-form-label">Filter</label>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Motor No.</span>
                                <input name="motorno" class="form-control" list="motorno_list" id="motorno" value="<?php echo e(Request::get('motorno')); ?>" placeholder="Type to search...">
                                <datalist id="motorno_list">
                                    <?php $__currentLoopData = $motorbike_no_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motorbike->motorno); ?>"> <?php echo e($motorbike->motorno); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <select class="form-select" name="motorType" id="motorType">
                                    <option value="">Type</option>
                                    <option value="1" <?php if(Request::get('motorType') == 1): ?> selected <?php endif; ?>>Big AT</option>
                                    <option value="2" <?php if(Request::get('motorType') == 2): ?> selected <?php endif; ?>>Auto</option>
                                    <option value="3" <?php if(Request::get('motorType') == 3): ?> selected <?php endif; ?>>50cc AT</option>
                                    <option value="4" <?php if(Request::get('motorType') == 4): ?> selected <?php endif; ?>>Manual</option>
                                </select>
                                <input name="motorModel" class="form-control" list="motorModel_list" id="motorModel" value="<?php echo e(Request::get('motorModel')); ?>" placeholder="Type to search...">
                                <datalist id="motorModel_list">
                                    <?php $__currentLoopData = $motorbike_model_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motorbike->motorModel); ?>"> <?php echo e($motorbike->motorModel); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Color</span>
                                <input name="motorColor" class="form-control" list="motorColor_list" id="motorColor" value="<?php echo e(Request::get('motorColor')); ?>" placeholder="Type to search...">
                                <datalist id="motorColor_list">
                                    <?php $__currentLoopData = $motorbike_color_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motorbike->motorColor); ?>"> <?php echo e($motorbike->motorColor); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Purchase Date</span>
                                <input class="form-control" type="date" name="purchaseDate" value="<?php echo e(Request::get('purchaseDate')); ?>" id="purchaseDate">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Motor Status</span>
                                <select class="form-select" name="motorStatus" id="motorStatus">
                                    <option value="">-- Status --</option>
                                    <option value="1" <?php if(Request::get('motorStatus') == 1): ?> selected <?php endif; ?>>In Stock</option>
                                    <option value="2" <?php if(Request::get('motorStatus') == 2): ?> selected <?php endif; ?>>On Rent</option>
                                    <option value="3" <?php if(Request::get('motorStatus') == 3): ?> selected <?php endif; ?>>Sold</option>
                                    <option value="4" <?php if(Request::get('motorStatus') == 4): ?> selected <?php endif; ?>>Stolen</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Price</span>
                                <input name="totalPurchasePrice" class="form-control" list="totalPurchasePrice_list" id="totalPurchasePrice" value="<?php echo e(Request::get('totalPurchasePrice')); ?>" placeholder="Type to search...">
                                <datalist id="totalPurchasePrice_list">
                                    <?php $__currentLoopData = $motorbike_price_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motorbike->totalPurchasePrice); ?>"> <?php echo e($motorbike->totalPurchasePrice); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="input-group">
                                <button class="btn btn-warning">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="ms-3 me-3">
                
                <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <label class="col-lg-12 col-form-label">Table Data</label>
            </div>
            <div class="table-responsive text-nowrap">
                <?php if(count($motorbikes) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorno', 'No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorModel', 'Model'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorType', 'Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorStatus', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('year', 'Year'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('purchaseDate', 'Purchase At'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('totalPurchasePrice', 'Purchase Price'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('plateNo', 'Plate No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorColor', 'Color'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('engineNo', 'Engine No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('chassisNo', 'Chassis No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                            <th class="text-primary" colspan="2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $motorbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th class="text-center">
                                    <a href="<?php echo e(route('motorbikes.show',$motorbike->motorID)); ?>"><?php echo e($motorbike->motorno); ?></a>
                                </th>
                                <th>
                                    <a href="<?php echo e(route('motorbikes.show',$motorbike->motorID)); ?>"><?php echo e($motorbike->motorModel); ?></a>
                                </th>
                                <?php if($motorbike->motorType == 1): ?>
                                    <td>Big AT</td>
                                <?php elseif($motorbike->motorType == 2): ?>
                                    <td>Auto</td>
                                <?php elseif($motorbike->motorType == 3): ?>
                                    <td>50cc AT</td>
                                    <?php elseif($motorbike->motorType == 4): ?>
                                    <td>Manual</td>
                                <?php endif; ?>
                                <?php if($motorbike->motorStatus == 1): ?>
                                <td>
                                    <span class="badge bg-primary text-white">
                                        In Stock
                                    </span>
                                </td>
                                <?php elseif($motorbike->motorStatus == 2): ?>
                                <td>
                                    <span class="badge bg-success text-white">
                                        On Rent
                                    </span>
                                </td>
                                <?php elseif($motorbike->motorStatus == 3): ?>
                                <td>
                                    <span class="badge bg-danger text-white">
                                        Sold
                                    </span>
                                </td>
                                <?php elseif($motorbike->motorStatus == 4): ?>
                                <td>
                                    <span class="badge bg-danger text-white">
                                        Lost / Stolen
                                    </span>
                                </td>
                                <?php elseif($motorbike->motorStatus == 5): ?>
                                <td>
                                    <span class="badge bg-primary text-white">
                                        Temp. Return
                                    </span>
                                </td>
                                <?php endif; ?>
                                <td><?php echo e($motorbike->year); ?></td>
                                <td><?php echo e($motorbike->purchaseDate); ?></td>
                                <td>$ <?php echo e($motorbike->totalPurchasePrice); ?>.00</td>
                                <td><?php echo e($motorbike->plateNo); ?></td>
                                <td><?php echo e($motorbike->motorColor); ?></td>
                                <td><?php echo e($motorbike->engineNo); ?></td>
                                <td><?php echo e($motorbike->chassisNo); ?></td>
                                <td><?php echo e($motorbike->user->name); ?></td>
                                <td class="justify-content-between ms-2 text-nowrap">
                                    <a href="<?php echo e(route('motorbikes.edit',$motorbike->motorID)); ?>" class="btn btn-primary btn-xs">Edit</a>
                                    <a href="<?php echo e(route('motorbikes.sold-stolen',$motorbike->motorID)); ?>" class="btn btn-danger btn-xs">Sold / Lost</a>
                                </td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('motorbikes.destroy', $motorbike->motorID)); ?>" onsubmit="return confirm('Are you want to delete Motorbike No. <?php echo e($motorbike->motorno); ?> !!!');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-secondary btn-xs">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <table class="table table-hover table-bordered text-nowrap mb-3">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorno', 'No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorType', 'Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorStatus', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('year', 'Year'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('purchaseDate', 'Purchase At'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('plateNo', 'Plate No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorModel', 'Model'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorColor', 'Color'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('engineNo', 'Engine No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('chassisNo', 'Chassis No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                            <th class="text-primary">Actions</th>
                        </tr>
                    </thead>
                </table>
                <p class="text-center">No motorbikes found.</p>

            <?php endif; ?>
            </div>
            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($motorbikes->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/motorbikes?page=<?php echo e($motorbikes->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                            <?php endif; ?>

                                <?php for($i = 1; $i <= $motorbikes->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($motorbikes->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/motorbikes?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($motorbikes->currentPage() < $motorbikes->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/motorbikes?page=<?php echo e($motorbikes->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <!--/ Basic Pagination -->
        </div>
        </div>
</div>

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/motorbikes/index.blade.php ENDPATH**/ ?>