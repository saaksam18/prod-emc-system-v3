

<?php $__env->startSection('title', 'Register New Role'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap-select-country.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('roles.index')); ?>">Role Management</a>
        </li>
        <li class="breadcrumb-item active">Register Role</li>
    </ol>
  </nav>
<div class="col-lg-12">
    <div class="card mb-4">
        <div class="card-body">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php echo Form::open(array('route' => 'roles.store','method'=>'POST')); ?>

            <div class="row mb-3">
                <div class="row mb-3">
                    <label class="form-label" for="basic-default-name">Name <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                    </div>
                </div>
                <div class="row mb-3">
                    <label class="form-label" for="basic-default-name">Permission <span class="text-danger">*</span></label>
                    <div class="input-group">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10px">No.</th>
                                <th style="width: 500px">Dashboard</th>
                                <th>View</th>
                                <th>Create</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center">1</td>
                                <td>Operation</td>
                                <?php $__currentLoopData = $permissions_op; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                    <!-- checkbox -->
                                        <label><?php echo e(Form::checkbox('permission[]', $value->name, false, array('class' => 'name'))); ?></label>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <td class="text-center">2</td>
                                <td>Role</td>
                                <?php $__currentLoopData = $permissions_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                    <!-- checkbox -->
                                        <label><?php echo e(Form::checkbox('permission[]', $value->name, false, array('class' => 'name'))); ?></label>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <td class="text-center">3</td>
                                <td>User</td>
                                <?php $__currentLoopData = $permissions_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                    <!-- checkbox -->
                                        <label><?php echo e(Form::checkbox('permission[]', $value->name, false, array('class' => 'name'))); ?></label>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <td class="text-center">4</td>
                                <td>Dashboard</td>
                                <?php $__currentLoopData = $permission_dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td colspan="4">
                                    <!-- checkbox -->
                                        <label><?php echo e(Form::checkbox('permission[]', $value->name, false, array('class' => 'name'))); ?></label>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <td class="text-center">5</td>
                                <td>All Report</td>
                                <?php $__currentLoopData = $permission_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td colspan="4">
                                    <!-- checkbox -->
                                        <label><?php echo e(Form::checkbox('permission[]', $value->name, false, array('class' => 'name'))); ?></label>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
            <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emcmotorbikerental.com/public_html/resources/views/roles/create.blade.php ENDPATH**/ ?>