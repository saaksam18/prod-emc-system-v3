

<?php $__env->startSection('title', 'Sold / Stolen'); ?>

<?php $__env->startSection('content'); ?>
<!-- Custom style1 Breadcrumb -->
<nav aria-label="breadcrumb">
      <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
          <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
          <a href="<?php echo e(route('motorbikes.index')); ?>">Motorbikes Management</a>
        </li>
        <li class="breadcrumb-item active">Sold / Stolen</li>
      </ol>
    </nav>
    <!--/ Custom style1 Breadcrumb -->
    <!-- Basic Layout -->
  <div class="col-xxl">
    <div class="card mb-4">
      <div class="card-body">
        
        <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo Form::model($motorbikes, ['method' => 'put','route' => ['motorbikes.soldStolenContract', $motorbikes->motorID]]); ?>

        <?php echo csrf_field(); ?>
          <div class="row mb-3">
            <?php echo Form::hidden('motorID', null, array('class' => 'form-control')); ?>

            <label class="col-sm-2 col-form-label" for="basic-default-name">Customer Name <span class="text-danger">*</span></label>
            <div class="input-group">
              <input name="CustomerName" class="form-control" list="customers" id="CustomerName" placeholder="Type to search...">
              <datalist id="customers">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->CustomerName); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </datalist>
              <!-- Button trigger modal -->
              <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
              Add New Customer
              </button>
            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-company">Motorbike <span class="text-danger">*</span></label>
            <div class="input-group">
              <span class="input-group-text">Motorbike No.</span>
                <?php echo Form::text('motorno', null, array('class' => 'form-control', 'readonly' => 'true')); ?>

            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-company">Transaction Date <span class="text-danger">*</span></label>
            <div class="input-group">
            <span class="input-group-text">Date</span>
            <?php echo Form::date('returnDate', null, array('class' => 'form-control')); ?>

            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-company">Sold / Stolen <span class="text-danger">*</span></label>
            <div class="input-group">
            <span class="input-group-text">Sold / Stolen</span>
            <select class="form-select" name="transactionType" id="transactionType">
              <option value="3" selected>Sold</option>
              <option value="4">Stolen</option>
            </select>
            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-name">Total Purchase Price <span class="text-danger">*</span></label>
            <div class="input-group">
              <span class="input-group-text">$</span>
              <?php echo Form::text('price', null, array('class' => 'form-control')); ?>

              <span class="input-group-text">.00</span>
            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label" for="basic-default-name">Staff Incharge <span class="text-danger">*</span></label>
            <div class="input-group">
              <select class="form-select" name="staffId" aria-label="staffId">
                <option value="">-- Staff Incharge --</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          
          <div class="row">
            <div class="col-sm-10">
              <button type="submit" class="btn btn-warning">Save</button>
            </div>
          </div>
          <?php echo Form::close(); ?>

      </div>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-lg" id="staticBackdrop" role="dialog" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Add New Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="card-body">
                <form action="<?php echo e(url('customers')); ?>" method="post">
                <?php echo csrf_field(); ?>
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="basic-default-name">Customer Name <strong class="text-danger">*</strong> </label>
                    <div class="input-group">
                    <input type="text" name="CustomerName" class="form-control" id="defaultFormControlInput" placeholder="" aria-describedby="defaultFormControlHelp" />
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Customer Detail <strong class="text-danger">*</strong></label>
                    <div class="input-group">
                      <input class="form-control" name="nationality" placeholder="-- Nationality --" list="nationality" type="text" />
                      <datalist id="nationality">
                        <?php $__currentLoopData = $countriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($country->nationality); ?>"> <?php echo e($country->nationality); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </datalist>                    
                      
                      <select id="gender" name="gender" class="form-select">
                        <option value="N/A">-- Select Gender --</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="In-Between">In-Between</option>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3" id="newContactDiv">
                    <label class="col-sm-2 col-form-label">Customer Contact <strong class="text-danger">*</strong></label>
                    <div class="input-group">
                      <select name="inputs[0][contactType]" class="form-select">
                        <option value="N/A">-- Contact Type --</option>
                          <option value="Mobile Phone">Mobile Phone</option>
                          <option value="Facebook">Facebook</option>
                          <option value="Telegram">Telegram</option>
                          <option value="WhatsApp">WhatsApp</option>
                          <option value="Others">Others</option>
                        </select>
                      <input type="text" name="inputs[0][contactDetail]" class="form-control" id="contactDetail" placeholder="Contact Details" aria-describedby="contactDetail" />
                      <button type="button" id="add-button" name="add-button" class="btn btn-warning">Add More</button>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                    <div class="input-group">
                        <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>
                    <div class="row mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Remark/Comment</label>
                    <div class="input-group">
                        <textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="1"></textarea>
                    </div>
                  </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-10">
                      <button type="submit" class="btn btn-warning">Save</button>
                      <button type="button" class="btn btn-primary">
                        <a href="<?php echo e(route('customers.index')); ?>" style="color: white">View All Customer</a>
                      </button>
                    </div>
                  </div>
                </form>
            </div>
          </div>
      </div>
    </div>
  </div>
  </div>
</div>

<script>
  var i = 0;
  $('#add-button').click(function () {
    ++i;
    $('#newContactDiv').append (
      `
        <div class="input-group mt-3" id="newContactDivPlus">
          <select name="inputs[`+i+`][contactType]" class="form-select">
            <option value="N/A">-- Contact Type --</option>
              <option value="Mobile Phone">Mobile Phone</option>
              <option value="Facebook">Facebook</option>
              <option value="Telegram">Telegram</option>
              <option value="WhatsApp">WhatsApp</option>
              <option value="Others">Others</option>
          </select>
          <input type="text" name="inputs[`+i+`][contactDetail]" placeholder="Contact Details" class="form-control" />
          <button type="button" id="rm-button" name="rm-button" class="btn btn-danger">Remove</button>
        </div>
      `);
  });

  $(document).on('click', '#rm-button', function() {
    $(this).parents('#newContactDivPlus').remove();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/motorbikes/sold-and-stolen.blade.php ENDPATH**/ ?>