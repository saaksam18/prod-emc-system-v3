

<?php $__env->startSection('title', 'Rental Management'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
<ol class="breadcrumb breadcrumb-style1">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Home</a>
    <li class="breadcrumb-item active">Rental Management</li>
</ol>
</nav>
<div class="row mb-3">
    <div class="col-sm-10">
        <button type="button" class="btn btn-warning">
        <a href="<?php echo e(route('rentals.create')); ?>" style="color: white">Create New Transaction</a>
        </button>
    </div>
</div>

    
    <div class="row">
        <div class="col-lg-4 mb-3">
            <div class="card">
                <div class="p-2 text-center">
                    <div class="card-title">
                        <h5 class="text-nowrap mt-1 text-start ms-2">Motorbikes</h5>
                        <div class="row">
                            <div class="col-4">
                                <span class="badge bg-label-warning rounded-pill mt-3">In Stock</span>
                                <h6 class="mb-0 mt-1"><?php echo e($totalInstock); ?> Scooters</h6>
                            </div>
                            <div class="col-4">
                                <span class="badge bg-label-success rounded-pill mt-3">On Rent</span>
                                <h6 class="mb-0 mt-1"><?php echo e($totalOnRent); ?> Scooters</h6>
                            </div>
                            <div class="col-4">
                                <span class="badge bg-label-primary rounded-pill mt-3">Total</span>
                                <h6 class="mb-0 mt-1"><?php echo e($totalMotors); ?> Scooters</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8 d-flex justify-content-between gap-4">
            <div class="col-lg-3 mb-3">
                <div class="card">
                    <div class="p-2">
                        <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                                <img src="<?php echo e(asset('assets/img/icons/unicons/paypal.png')); ?>" alt="Credit Card" class="rounded">
                            </div>
                        </div>
                    <span class="fw-semibold d-block mb-1">Cash Deposit</span>
                    <h3 class="card-title text-nowrap mb-1">$<?php echo e($countCashs); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 mb-3">
                <div class="card">
                    <div class="p-2">
                        <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                                <img src="<?php echo e(asset('assets/img/icons/unicons/cc-primary.png')); ?>" alt="Credit Card" class="rounded">
                            </div>
                        </div>
                    <span class="fw-semibold d-block mb-1">P.P Deposit</span>
                    <h3 class="card-title mb-1"><?php echo e($countPPs); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 mb-3">
                <div class="card">
                    <div class="p-2">
                        <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                                <img src="<?php echo e(asset('assets/img/icons/unicons/chart.png')); ?>" alt="Credit Card" class="rounded">
                            </div>
                        </div>
                    <span class="fw-semibold d-block mb-1">Customer Late Payment</span>
                    <h3 class="card-title mb-1"><?php echo e($cus_late_payment); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <h5 class="card-header bg-primary text-white">Rental Management</h5>
                
                <form action="" method="GET">
                    <div class="ms-3 me-3">
                        <div class="row">
                            <label class="col-form-label">Filter</label>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Customer Name</span>
                                    <input name="CustomerName" class="form-control" list="customers" id="CustomerName" value="<?php echo e(Request::get('CustomerName')); ?>" placeholder="Type to search...">
                                    <datalist id="customers">
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->CustomerName); ?>"> <?php echo e($customer->CustomerName); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Motorbike No.</span>
                                    <input name="motorno" class="form-control" list="motorno_list" id="motorno" value="<?php echo e(Request::get('motorno')); ?>" placeholder="Type to search...">
                                    <datalist id="motorno_list">
                                        <?php $__currentLoopData = $motorbike_no_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorbike->motorno); ?>"> <?php echo e($motorbike->motorno); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <select class="form-select" name="motorType" id="motorType">
                                        <option value="">Type</option>
                                        <option value="1" <?php if(Request::get('motorType') == 1): ?> selected <?php endif; ?>>Big AT</option>
                                        <option value="2" <?php if(Request::get('motorType') == 2): ?> selected <?php endif; ?>>Auto</option>
                                        <option value="3" <?php if(Request::get('motorType') == 3): ?> selected <?php endif; ?>>50cc AT</option>
                                        <option value="4" <?php if(Request::get('motorType') == 4): ?> selected <?php endif; ?>>Manual</option>
                                    </select>
                                    <input name="motorModel" class="form-control" list="motorModel_list" id="motorModel" value="<?php echo e(Request::get('motorModel')); ?>" placeholder="Type to search...">
                                    <datalist id="motorModel_list">
                                        <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rental->motorInfor->motorModel); ?>"> <?php echo e($rental->motorInfor->motorModel); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Status</span>
                                    <select class="form-select" name="transactionType" id="transactionType">
                                        <option value="">-- Status --</option>
                                        <?php $__currentLoopData = $rental_tran_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($motorbike->transactionType == 5): ?>
                                                <option value="5" <?php if(Request::get('transactionType') == 5): ?> selected <?php endif; ?>>Temp. Return</option>
                                            <?php elseif($motorbike->transactionType == 3): ?>
                                                <option value="3" <?php if(Request::get('transactionType') == 3): ?> selected <?php endif; ?>>Sold</option>
                                            <?php elseif($motorbike->transactionType == 4): ?>
                                                <option value="4" <?php if(Request::get('transactionType') == 4): ?> selected <?php endif; ?>>Stolen</option>
                                            <?php else: ?>
                                                <option value="<?php echo e($motorbike->transactionType); ?>" <?php if(Request::get('transactionType') == $motorbike->transactionType): ?> selected <?php endif; ?>><?php echo e($motorbike->transactionType); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Nationality</span>
                                    <input name="nationality" class="form-control" list="nationality_list" id="nationality" value="<?php echo e(Request::get('nationality')); ?>" placeholder="Type to search...">
                                    <datalist id="nationality_list">
                                        <?php $__currentLoopData = $countriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->nationality); ?>"> <?php echo e($country->nationality); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Rental Date</span>
                                    <input class="form-control" type="date" name="rentalDay" value="<?php echo e(Request::get('rentalDay')); ?>" id="rentalDay">
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Return Date</span>
                                    <input class="form-control" type="date" name="returnDate" value="<?php echo e(Request::get('returnDate')); ?>" id="returnDate">
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Price</span>
                                    <input name="price" class="form-control" list="price_list" id="price" value="<?php echo e(Request::get('price')); ?>" placeholder="Type to search...">
                                    <datalist id="price_list">
                                        <?php $__currentLoopData = $rental_price_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorbike->price); ?>"> <?php echo e($motorbike->price); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="input-group">
                                    <button class="btn btn-warning">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                
            <div class="ms-3 me-3">
                
                <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <label class="col-form-label">Table Data</label>
            </div>
                <div class="table-responsive text-nowrap">
                    <?php if(count($rentals) > 0): ?>
                    <table class="table table-hover table-bordered text-nowrap">
                        <thead>
                            <tr>
                                <th class="text-primary">Actions</th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorno', 'Motor No.'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorType', 'Type'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorModel', 'Model'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                                </th>
                                <th class="text-primary">
                                    Deposit
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rental->returnDate <= now()): ?>
                                <tr class="table-danger">
                            <?php else: ?>
                                <tr>
                            <?php endif; ?>
                                    <td>
                                        <?php echo Form::open(['method' => 'get','route' => ['rentals.edit', $rental->rentalID],'style'=>'display:inline']); ?>

                                            <?php echo Form::submit('Actions', ['class' => 'btn btn-primary btn-xs']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('rentals.show',$rental->rentalID)); ?>"><?php echo e($rental->customer->CustomerName); ?></a>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('rentals.changeMotorEdit',$rental->rentalID)); ?>"><?php echo e($rental->motorInfor->motorno); ?></a>
                                    </td>
                                    <?php if($rental->motorInfor->motorType == 1): ?>
                                        <td class="text-center">Big AT</td>
                                    <?php elseif($rental->motorInfor->motorType == 2): ?>
                                        <td class="text-center">Auto</td>
                                    <?php elseif($rental->motorInfor->motorType == 3): ?>
                                        <td class="text-center">50cc AT</td>
                                        <?php elseif($rental->motorInfor->motorType == 4): ?>
                                        <td class="text-center">Manual</td>
                                    <?php endif; ?>
                                    <td><?php echo e($rental->motorInfor->motorModel); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($rental->returnDate))); ?></td>
                                    <?php if($rental->transactionType == 'New Rental'): ?>
                                        <td>
                                            <span class="badge bg-label-success"><?php echo e($rental->transactionType); ?></span>
                                        </td>
                                    <?php elseif($rental->transactionType == 'Extension'): ?>
                                    <td>
                                        <span class="badge bg-label-info"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                    <?php elseif($rental->transactionType == '5'): ?>
                                    <td>
                                        <span class="badge bg-label-primary">Temp. Return</span>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <span class="badge bg-label-primary"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="<?php echo e(route('rentals.exchange-deposit',$rental->rentalID)); ?>">
                                            <?php $__currentLoopData = $rental_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <?php if($rental_deposit->rentalID == $rental->rentalID): ?>
                                                    <?php if($rental_deposit->customerID == $rental->customerID): ?>
                                                        <?php if($rental_deposit->currDepositType == 'Money'): ?>
                                                            <li>
                                                                <?php echo e($rental_deposit->currDepositType); ?> : $<?php echo e($rental_deposit->currDeposit); ?>

                                                            </li>
                                                        <?php else: ?>
                                                            <li>
                                                                <?php echo e($rental_deposit->currDepositType); ?> : <?php echo e($rental_deposit->currDeposit); ?>

                                                            </li>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        No Data
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </a>
                                    </td>
                                    <td>$<?php echo e($rental->price); ?></td>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($rental->staff_id == $user->id): ?>
                                            <td><?php echo e($user->name); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($rental->user->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
        <!--/ Basic Pagination -->
                    <?php else: ?>
                    <table class="table table-bordered text-nowrap">
                        <thead>
                            <tr>
                                <th class="text-primary">Actions</th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorno', 'Motor No.'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorType', 'Type'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorModel', 'Model'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                                </th>
                                <th class="text-primary">
                                    Deposit
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                </th>
                            </tr>
                        </thead>
                  </table><br/>
                  <p class="text-center">No transactions found.</p>
                <?php endif; ?>
                </div>

                <!-- Basic Pagination -->
                <div class="demo-inline-spacing">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <?php if($rentals->currentPage() > 1): ?>
                                    <li class="page-item first">
                                        <a href="/rentals?page=<?php echo e($rentals->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                    </li>
                            <?php endif; ?>

                                    <?php for($i = 1; $i <= $rentals->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($rentals->currentPage() == $i ? 'active' : ''); ?>">
                                            <a class="page-link" href="/rentals?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                <?php if($rentals->currentPage() < $rentals->lastPage()): ?>
                                    <li class="page-item last">
                                        <a href="/rentals?page=<?php echo e($rentals->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                    </li>
                                <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
         </div>
    </div>
  </div>

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/rentals/index.blade.php ENDPATH**/ ?>