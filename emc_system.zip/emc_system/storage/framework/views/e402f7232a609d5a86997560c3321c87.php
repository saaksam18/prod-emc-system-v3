<?php $__env->startSection('title', 'Customer Detail'); ?>

<?php $__env->startSection('content'); ?>


<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('customers.index')); ?>">Customer Information</a>
        </li>
        <li class="breadcrumb-item active">Customers Details</li>
    </ol>
</nav>


<div class="row mb-3">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-primary text-white">Customers Details</h5>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        
                        <tr>
                            <th class="bg-primary text-white fw-bold">Basic Informations</th>
                            <th class="fw-bold">Customer ID</th>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="fw-bold">
                                    <a href="<?php echo e(route('customers.edit', $customer->customerID)); ?>"><?php echo e($customer->customerID); ?></a>
                                </th>
                                <td colspan="2">
                                    <?php if($customer->CustomerName > 0): ?>
                                        <tr>
                                            <td>
                                                <th class="fw-bold">Customer Name</th>
                                                <th class="fw-bold">
                                                    <a href="<?php echo e(route('customers.edit', $customer->customerID)); ?>"><?php echo e($customer->CustomerName); ?></a>
                                                </th>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($customer->gender > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Gender</th>
                                                <td><?php echo e($customer->gender); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($customer->nationality > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Nationality</th>
                                                <td><?php echo e($customer->nationality); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td>
                                            <th>Contact</th>
                                            <td>
                                                <?php $__currentLoopData = $customer->contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($contact->is_Active == 1): ?>
                                                        <li>
                                                            <?php echo e($contact->contactType); ?> : <?php echo e($contact->contactDetail); ?>

                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </td>
                                    </tr>
                                    
                                    <?php if($customer->address > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Address</th>
                                                <td><?php echo e($customer->address); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($customer->comment > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Comment</th>
                                                <td><?php echo e($customer->comment); ?></td>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        

                        
                        <?php if(count($rentals) > 0): ?>
                        <tr>
                            <th class="bg-warning text-white fw-bold">
                                Motorbike Rental
                                <button id="btnRental"class="btn btn-xs bg-white text-warning" style="float: right">
                                    <i id="arrowRental" class="fa fa-arrow-circle-down fa-lg" aria-hidden="true"></i>
                                </button>
                            </th>
                            <th class="fw-bold">Latest Status: Incharge Staff <span class="text-danger">(<?php echo e($staff_name); ?>)</span></th>
                            <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="fw-bold">
                                <?php $__currentLoopData = $rental_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status->transactionType == 'New Rental'): ?>
                                            <span class="badge bg-success text-white"><?php echo e($rental->transactionType); ?></span>
                                    <?php elseif($status->transactionType == 'Extension'): ?>
                                        <span class="badge bg-info text-white"><?php echo e($rental->transactionType); ?></span>
                                    <?php elseif($status->transactionType == 'Exchange'): ?>
                                        <span class="badge bg-secondary text-white"><?php echo e($rental->transactionType); ?></span>
                                    <?php elseif($status->transactionType == '3'): ?>
                                        <span class="badge bg-danger text-white">Sold</span>
                                    <?php elseif($status->transactionType == '4'): ?>
                                        <span class="badge bg-danger text-white">Stolen</span>
                                    <?php elseif($status->transactionType == '5'): ?>
                                        <span class="badge bg-primary text-white">Temp. Return</span>
                                    <?php elseif($status->transactionType == 'Return'): ?>
                                        <span class="badge bg-danger text-white">Return</span>
                                    <?php else: ?>
                                        <span class="badge bg-primary text-white">No Data</span>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                                <td>
                                    <tr id="deposit" style="display: none">
                                        <td>
                                            <th>Latest Deposit</th>
                                            <td>
                                                <?php $__currentLoopData = $customer->deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($deposit->is_Active == 1): ?>
                                                        <li>
                                                            <?php echo e($deposit->currDepositType); ?> : <?php echo e($deposit->currDeposit); ?>

                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </td>
                                    </tr>
                                    <?php if($rental->created_at != null): ?>
                                        <tr id="br" style="display: none">
                                            <td>
                                                <th>Begin Rental</th>
                                                <?php $__currentLoopData = $begin_rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $begin_rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($begin_rental->created_at->format('d-M-Y')); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr id="lastRental" style="display: none">
                                        <td>
                                            <th>Last Rental</th>
                                            <?php $__currentLoopData = $rental_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last_rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($last_rental->updated_at->format('d-M-Y')); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <tr id="timeOE" style="display: none">
                                        <td>
                                            <th>Time of Extension</th>
                                            <td><?php echo e($toE); ?></td>
                                        </td>
                                    </tr>
                                    <tr id="totalRP" style="display: none">
                                        <td>
                                            <th>Total Rental Period</th>
                                            <td><?php echo e($trP); ?> Days</td>
                                        </td>
                                    </tr>
                                </td>
                                <?php if($trPrice > 0): ?>
                                <tr id="tp" style="display: none">
                                    <td class="justify-content-center">
                                        <th>Total Price</th>
                                        <td>$<?php echo e($trPrice); ?></td>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endif; ?>
                        

                        
                        <?php if(count($visas) > 0): ?>
                        <tr>
                            <th class="bg-dark text-white fw-bold">
                                Visa Extension
                                <button id="btnVisa"class="btn btn-xs bg-white text-dark" style="float: right">
                                    <i id="arrowVisa" class="fa fa-arrow-circle-down fa-lg" aria-hidden="true"></i>
                                </button>
                            </th>
                            <?php $__currentLoopData = $visas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="fw-bold">Visa Reiminder Status</th>
                                <?php if($visa->is_Active == 1): ?>
                                    <td class="fw-bold">
                                        <span class="badge bg-warning text-white">Remind Date Coming</span>
                                    </td>
                                <?php else: ?>
                                    <td class="fw-bold">
                                        <span class="badge bg-danger text-white">Reminded</span>
                                    </td>
                                <?php endif; ?>
                            <td>
                                <tr id="jv_visa_type" style="display: none">
                                    <td>
                                        <th>Latest Visa Type</th>
                                        <td><?php echo e($visa->visaType); ?></td>
                                    </td>
                                </tr>
                                <?php if($visa->amount > 0): ?>
                                    <tr id="jv_visa_amount" style="display: none">
                                        <td>
                                            <th>Latest Passport Amount</th>
                                                <?php if($visa->amount == 1): ?>
                                                    <td><?php echo e($visa->amount); ?> Passport</td>
                                                <?php else: ?>
                                                    <td><?php echo e($visa->amount); ?> Passports</td>
                                                <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($v_last_expirations != null): ?>
                                <tr id="jv_visa_exDate" style="display: none">
                                    <td>
                                        <th>Last Expiration Date</th>
                                            <td><?php echo e($v_last_expirations->format('d-M-Y')); ?></td>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php if($v_last_extensions != null): ?>
                                <tr id="jv_visa_lastExt" style="display: none">
                                    <td>
                                        <th>Last Extension</th>
                                            <td><?php echo e($v_last_extensions->format('d-M-Y')); ?></td>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <tr id="jv_visa_ToE" style="display: none">
                                    <td>
                                        <th>Time of Extension</th>
                                        <td><?php echo e($vToE); ?></td>
                                    </td>
                                </tr>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endif; ?>
                        

                        
                        <?php if(count($wps) > 0): ?>
                        <tr>
                            <th class="bg-secondary text-white fw-bold">
                                Work Permit Renewal
                                <button id="btnWP"class="btn btn-xs bg-white text-secondary" style="float: right">
                                    <i id="arrowWP" class="fa fa-arrow-circle-down fa-lg" aria-hidden="true"></i>
                                </button>
                            </th>
                            <?php $__currentLoopData = $wps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wp_s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="fw-bold">WP Reiminder Status</th>
                                <?php if($wp_s->is_Active == 1): ?>
                                    <td class="fw-bold">
                                        <span class="badge bg-warning text-white">Remind Date Coming</span>
                                    </td>
                                <?php else: ?>
                                    <td class="fw-bold">
                                        <span class="badge bg-danger text-white">Reminded</span>
                                    </td>
                                <?php endif; ?>
                            <td>
                                <?php if($w_last_expirations != null): ?>
                                <tr id="jv_wp_lastExpDate" style="display: none">
                                    <td>
                                            <th>Last Expiration Date</th>
                                            <td><?php echo e($w_last_expirations->format('d-M-Y')); ?></td>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php if($w_last_extensions != null): ?>
                                <tr id="jv_wp_LastRDate" style="display: none">
                                    <td>
                                            <th>Last Renawal Date</th>
                                            <td><?php echo e($w_last_extensions->format('d-M-Y')); ?></td>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <tr id="jv_wp_TOE" style="display: none">
                                    <td>
                                        <th>Time of Extension</th>
                                        <td><?php echo e($wToE); ?></td>
                                    </td>
                                </tr>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endif; ?>
                        
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="row mb-3" id="rentalDiv" style="display: none">
    <div class="col-md-12">
        <div class="card">
                <h6 class="card-header bg-warning text-white fw-bold">RENTAL LOGS</h6>
            <div class="card-body">
                <form action="" method="GET">
                    <div class="row">
                        <label class="col-lg-12 col-form-label">Filter</label>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Motorbike No.</span>
                                <input name="motorno" class="form-control" list="motorno_list" id="motorno" value="<?php echo e(Request::get('motorno')); ?>" placeholder="Type to search...">
                                <datalist id="motorno_list">
                                    <?php $__currentLoopData = $motorbike_no_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motorbike->motorno); ?>"><?php echo e($motorbike->motorno); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <select class="form-select" name="contactType" id="contactType">
                                    <option value="">Contact Type</option>
                                    <?php $__currentLoopData = $customer_contact_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact_ty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer_contact_ty->contactType); ?>" <?php if(Request::get('contactType') == $customer_contact_ty->contactType): ?> selected <?php endif; ?>><?php echo e($customer_contact_ty->contactType); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input name="contactDetail" class="form-control" list="contactD_list" id="contactDetail" value="<?php echo e(Request::get('contactDetail')); ?>" placeholder="Type to search...">
                                <datalist id="contactD_list">
                                    <?php $__currentLoopData = $customer_contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rental->contactDetail); ?>"> <?php echo e($rental->contactDetail); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Rental Date</span>
                                <input class="form-control" type="date" name="rentalDay" value="<?php echo e(Request::get('rentalDay')); ?>" id="rentalDay">
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Return Date</span>
                                <input class="form-control" type="date" name="returnDate" value="<?php echo e(Request::get('returnDate')); ?>" id="returnDate">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Status</span>
                                <select class="form-select" name="transactionType" id="transactionType">
                                    <option value="">-- Status --</option>
                                    <?php $__currentLoopData = $rental_tran_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($motorbike->transactionType == 5): ?>
                                            <option value="5" <?php if(Request::get('transactionType') == 5): ?> selected <?php endif; ?>>Temp. Return</option>
                                        <?php elseif($motorbike->transactionType == 3): ?>
                                            <option value="3" <?php if(Request::get('transactionType') == 3): ?> selected <?php endif; ?>>Sold</option>
                                        <?php elseif($motorbike->transactionType == 4): ?>
                                            <option value="4" <?php if(Request::get('transactionType') == 4): ?> selected <?php endif; ?>>Stolen</option>
                                        <?php else: ?>
                                            <option value="<?php echo e($motorbike->transactionType); ?>" <?php if(Request::get('transactionType') == $motorbike->transactionType): ?> selected <?php endif; ?>><?php echo e($motorbike->transactionType); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Price</span>
                                <input name="price" class="form-control" list="price_list" id="price" value="<?php echo e(Request::get('price')); ?>" placeholder="Type to search...">
                                <datalist id="price_list">
                                    <?php $__currentLoopData = $rental_price_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motorbike->price); ?>"> <?php echo e($motorbike->price); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="input-group">
                                <button class="btn btn-warning">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="table-responsive text-nowrap">
                <?php if(count($rental_logs) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorID', 'Motor No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Deposit'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('rentalDay', 'Rental Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rental_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <?php echo e($rental->motorInfor->motorno); ?> 
                                </td>
                                <td>
                                    <?php $__currentLoopData = $rental_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <?php if($rental_deposit->rentalID == $rental->rentalID): ?>
                                            <?php if($rental_deposit->customerID == $rental->customerID): ?>
                                                <?php if($rental_deposit->currDepositType == 'Money'): ?>
                                                    <li>
                                                        <?php echo e($rental_deposit->currDepositType); ?> : $<?php echo e($rental_deposit->currDeposit); ?>

                                                    </li>
                                                <?php else: ?>
                                                    <li>
                                                        <?php echo e($rental_deposit->currDepositType); ?> : <?php echo e($rental_deposit->currDeposit); ?>

                                                    </li>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($contact->contactType); ?> : <?php echo e($contact->contactDetail); ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                
                                <?php if($rental->transactionType == 'New Rental'): ?>
                                    <td>
                                        <span class="badge bg-label-success"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                <?php elseif($rental->transactionType == 'Extension'): ?>
                                <td>
                                    <span class="badge bg-label-info"><?php echo e($rental->transactionType); ?></span>
                                </td>
                                <?php elseif($rental->transactionType == '5'): ?>
                                <td>
                                    <span class="badge bg-label-primary">Temp. Return</span>
                                </td>
                                <?php elseif($rental->transactionType == 'Return'): ?>
                                <td>
                                    <span class="badge bg-label-danger"><?php echo e($rental->transactionType); ?></span>
                                </td>
                                <?php else: ?>
                                <td>
                                    <span class="badge bg-label-primary"><?php echo e($rental->transactionType); ?></span>
                                </td>
                                <?php endif; ?>
                                <td><?php echo e(date('d-M-Y', strtotime($rental->rentalDay))); ?></td>
                                <td><?php echo e(date('d-M-Y', strtotime($rental->returnDate))); ?></td>
                                <td>$<?php echo e($rental->price); ?></td>
                                <td><?php echo e($rental->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <table class="table table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorno', 'Motorbike No.'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Transaction Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                </table><br/>
                <p class="text-center">No transactions found.</p>
            <?php endif; ?>
            </div>
            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($rental_logs->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/rentals/<?php echo e($rental->rentalID); ?>?page=<?php echo e($rental_logs->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                        <?php endif; ?>

                                <?php for($i = 1; $i <= $rental_logs->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($rental_logs->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/rentals/<?php echo e($rental->rentalID); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($rental_logs->currentPage() < $rental_logs->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/rentals/<?php echo e($rental->rentalID); ?>?page=<?php echo e($rental_logs->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <!--/ Basic Pagination -->
        </div>
        </div>
</div>



<?php if(count($visas) > 0): ?>
<div class="row mb-3" id="visaDiv" style="display: none">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-dark text-white fw-bold">VISA LOGS</h5>
            
            <form action="" method="GET">
                <div class="ms-3 me-3">
                    <div class="row">
                        <label class="col-form-label">Filter</label>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Status</span>
                                <select class="form-select" name="status" id="status">
                                    <option value="">-- Status --</option>
                                    <?php $__currentLoopData = $statuss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($status->is_Active == 1): ?>
                                            <option value="1" <?php if(Request::get('status') == 1): ?> selected <?php endif; ?>>Remind Date Coming</option>
                                        <?php else: ?>
                                            <option value="0">Reminded</option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Visa Type</span>
                                <input class="form-control" type="text" name="visaType" id="visaType" value="<?php echo e(Request::get('visaType')); ?>">
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Expire Date</span>
                                <input class="form-control" type="date" name="expireDate" id="expireDate" value="<?php echo e(Request::get('expireDate')); ?>">
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Incharger</span>
                                <select class="form-select" name="staff_id" id="staff_id">
                                    <option value="">-- Name --</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>" <?php if(Request::get('staff_id') == $user->id): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="input-group">
                                <button class="btn btn-warning">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="ms-3 me-3">
                <label class="col-lg-12 col-form-label">Table Data</label>
            </div>
            <div class="table-responsive text-nowrap">
                <?php if(count($visa_logs) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('is_Active', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaType', 'Vias Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expire Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $visa_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($visa->is_Active > 0): ?>
                            <tr>
                        <?php else: ?>
                            <tr class="table-danger">
                        <?php endif; ?>
                                <td>
                                    <?php echo e($visa->customer->CustomerName); ?>

                                </td>
                                <?php if($visa->is_Active == 0): ?>
                                    <td>
                                        <span class="badge bg-label-danger">Reminded</span>
                                    </td>
                                <?php else: ?>
                                <td>
                                    <span class="badge bg-label-warning">Remind Date Coming</span>
                                </td>
                                <?php endif; ?>
                                <td><?php echo e($visa->visaType); ?></td>
                                <td><?php echo e(date('d-M-Y', strtotime($visa->expireDate))); ?></td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($visa->staff_id == $user->id): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($visa->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <table class="table table-hover table-bordered text-nowrap mb-3">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('is_Active', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaType', 'Vias Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expire Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                </table>
                <p class="text-center">No motorbikes found.</p>

            <?php endif; ?>
            </div>
            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($visa_logs->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/visas/<?php echo e($visa->visaID); ?>?page=<?php echo e($visa_logs->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                            <?php endif; ?>

                                <?php for($i = 1; $i <= $visa_logs->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($visa_logs->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/visas/<?php echo e($visa->visaID); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($visa_logs->currentPage() < $visa_logs->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/visas/<?php echo e($visa->visaID); ?>?page=<?php echo e($visa_logs->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <!--/ Basic Pagination -->
        </div>
    </div>
</div>
<?php endif; ?>



<?php if(count($wps) > 0): ?>
<div class="row mb-3" id="wpDiv" style="display: none">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-secondary text-white fw-bold">WORK PERMIT LOGS</h5>
            
            <form action="" method="GET">
                <div class="ms-3 me-3">
                    <div class="row">
                        <label class="col-form-label">Filter</label>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Status</span>
                                <select class="form-select" name="status" id="status">
                                    <option value="">-- Status --</option>
                                    <?php $__currentLoopData = $statuss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($status->is_Active == 1): ?>
                                            <option value="1" <?php if(Request::get('status') == 1): ?> selected <?php endif; ?>>Remind Date Coming</option>
                                        <?php else: ?>
                                            <option value="0">Reminded</option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Expire Date</span>
                                <input class="form-control" type="date" name="wpExpireDate" id="wpExpireDate" value="<?php echo e(Request::get('wpExpireDate')); ?>">
                            </div>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <div class="input-group">
                                <span class="input-group-text">Incharger</span>
                                <select class="form-select" name="staff_id" id="staff_id">
                                    <option value="">-- Name --</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>" <?php if(Request::get('staff_id') == $user->id): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="input-group">
                                <button class="btn btn-warning">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="ms-3 me-3">
                <label class="col-lg-12 col-form-label">Table Data</label>
            </div>
            <div class="table-responsive text-nowrap">
                <?php if(count($wp_logs) > 0): ?>
                <table class="table table-hover table-bordered text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('is_Active', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('wpExpireDate', 'Expire Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $wp_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($wp->is_Active > 0): ?>
                            <tr>
                        <?php else: ?>
                            <tr class="table-danger">
                        <?php endif; ?>
                                <td>
                                    <?php echo e($wp->customer->CustomerName); ?>

                                </td>
                                <?php if($wp->is_Active == 0): ?>
                                    <td>
                                        <span class="badge bg-label-danger">Reminded</span>
                                    </td>
                                <?php else: ?>
                                <td>
                                    <span class="badge bg-label-warning">Remind Date Coming</span>
                                </td>
                                <?php endif; ?>
                                <td><?php echo e(date('d-M-Y', strtotime($wp->wpExpireDate))); ?></td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($wp->staff_id == $user->id): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($wp->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <table class="table table-hover table-bordered text-nowrap mb-3">
                    <thead>
                        <tr>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('is_Active', 'Status'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('visaType', 'Vias Type'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expireDate', 'Expire Date'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('staff_id', 'Incharger'));?>
                            </th>
                            <th>
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                            </th>
                        </tr>
                    </thead>
                </table>
                <p class="text-center">No motorbikes found.</p>

            <?php endif; ?>
            </div>
            <!-- Basic Pagination -->
            <div class="demo-inline-spacing">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-end">
                        <?php if($wp_logs->currentPage() > 1): ?>
                                <li class="page-item first">
                                    <a href="/wps/<?php echo e($wp->wpID); ?>?page=<?php echo e($wp_logs->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                </li>
                            <?php endif; ?>

                                <?php for($i = 1; $i <= $wp_logs->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($wp_logs->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="/wps/<?php echo e($wp->wpID); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                            <?php if($wp_logs->currentPage() < $wp_logs->lastPage()): ?>
                                <li class="page-item last">
                                    <a href="/wps/<?php echo e($wp->wpID); ?>?page=<?php echo e($wp_logs->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <!--/ Basic Pagination -->
        </div>
    </div>
</div>
<?php endif; ?>


<script>
    const btnVisa = document.getElementById("btnVisa");

    const jv_visa_type = document.getElementById("jv_visa_type");
    const jv_visa_amount = document.getElementById("jv_visa_amount");
    const jv_visa_exDate = document.getElementById("jv_visa_exDate");
    const jv_visa_lastExt = document.getElementById("jv_visa_lastExt");
    const jv_visa_ToE = document.getElementById("jv_visa_ToE");

    const visaDivArr = [jv_visa_type, jv_visa_amount, jv_visa_exDate, jv_visa_lastExt, jv_visa_ToE];
    const visaDiv = document.getElementById("visaDiv");

btnVisa.addEventListener("click", function() {
    visaDivArr.forEach(function(div) {
    if (div.style.display === "none") {
        div.style.display = "table-row";
        visaDiv.style.display = "block";
    } else {
        div.style.display = "none";
        visaDiv.style.display = "none";
    }
  });
});
    const arrowVisa = document.getElementById("arrowVisa");

    btnVisa.addEventListener("click", function() {
      // Check if icon has "fa-rotate-270" class
      if (arrowVisa.classList.contains("fa-rotate-180")) {
        // Remove "fa-rotate-270" class to reset rotation
        arrowVisa.classList.remove("fa-rotate-180");
      } else {
        // Add "fa-rotate-270" class to rotate 270 degrees
        arrowVisa.classList.add("fa-rotate-180");
      }
    });
</script>

<script>
    const btnWP = document.getElementById("btnWP");

    const jv_wp_lastExpDate = document.getElementById("jv_wp_lastExpDate");
    const jv_wp_LastRDate = document.getElementById("jv_wp_LastRDate");
    const jv_wp_TOE = document.getElementById("jv_wp_TOE");

    const wpDivArr = [jv_wp_lastExpDate, jv_wp_LastRDate, jv_wp_TOE];
    
    const wpDiv = document.getElementById("wpDiv");

btnWP.addEventListener("click", function() {
    wpDivArr.forEach(function(div) {
    if (div.style.display === "none") {
        div.style.display = "table-row";
        wpDiv.style.display = "block";
    } else {
        div.style.display = "none";
        wpDiv.style.display = "none";
    }
  });
});
    const arrowWP = document.getElementById("arrowWP");
    
    btnWP.addEventListener("click", function() {
      // Check if icon has "fa-rotate-270" class
      if (arrowWP.classList.contains("fa-rotate-180")) {
        // Remove "fa-rotate-270" class to reset rotation
        arrowWP.classList.remove("fa-rotate-180");
      } else {
        // Add "fa-rotate-270" class to rotate 270 degrees
        arrowWP.classList.add("fa-rotate-180");
      }
    });
</script>

<script>
    const rentalBTN = document.getElementById("btnRental");

    const deposit = document.getElementById("deposit");
    const br = document.getElementById("br");
    const lastRental = document.getElementById("lastRental");
    const timeOE = document.getElementById("timeOE");
    const totalRP = document.getElementById("totalRP");
    const tp = document.getElementById("tp");

    const rentalDivArr = [deposit, br, lastRental, timeOE, totalRP, tp];
    
    const rentalDiv = document.getElementById("rentalDiv");

btnRental.addEventListener("click", function() {
    rentalDivArr.forEach(function(div) {
    if (div.style.display === "none") {
        div.style.display = "table-row";
        rentalDiv.style.display = "block";
    } else {
        div.style.display = "none";
        rentalDiv.style.display = "none";
    }
  });
});

    const arrowRental = document.getElementById("arrowRental");
    
    rentalBTN.addEventListener("click", function() {
      // Check if icon has "fa-rotate-270" class
      if (arrowRental.classList.contains("fa-rotate-180")) {
        // Remove "fa-rotate-270" class to reset rotation
        arrowRental.classList.remove("fa-rotate-180");
      } else {
        // Add "fa-rotate-270" class to rotate 270 degrees
        arrowRental.classList.add("fa-rotate-180");
      }
    });
</script>

<style>
    .fa-arrow-circle-down {
      transition: transform 0.2s ease;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/customers/show.blade.php ENDPATH**/ ?>