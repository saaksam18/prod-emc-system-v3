<?php $__env->startSection('title', 'Rental Details'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('rentals.index')); ?>">Rental Management</a>
      </li>
      <li class="breadcrumb-item active">Rental Details</li>
    </ol>
  </nav>
    
    
    <div class="row mb-3">
        <div class="col-md-12">
            <div class="card">
                <h5 class="card-header bg-primary text-white">Rental Details</h5>
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="bg-warning text-white fw-bold">Motorbike Informations</th>
                                <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="fw-bold">Motorbike No.</th>
                                    <th class="fw-bold">
                                        <a href="<?php echo e(route('motorbikes.edit',$rental->motorID)); ?>"><?php echo e($rental->motorInfor->motorno); ?></a>
                                    </th>
                                    <td colspan="2">
                                        <?php if($rental->transactionType > 0): ?>
                                            <tr>
                                                <td>
                                                    <th>Status: Incharge Staff <span class="text-danger">(<?php echo e($staff_name); ?>)</span></th>
                                                    <?php if($rental->transactionType == 'New Rental'): ?>
                                                        <td>
                                                            <span class="badge bg-label-success"><?php echo e($rental->transactionType); ?></span>
                                                        </td>
                                                    <?php elseif($rental->transactionType == 'Extension'): ?>
                                                    <td>
                                                        <span class="badge bg-label-info"><?php echo e($rental->transactionType); ?></span>
                                                    </td>
                                                    <?php elseif($rental->transactionType == 'Exchange'): ?>
                                                    <td>
                                                        <span class="badge bg-label-primary"><?php echo e($rental->transactionType); ?></span>
                                                    </td>
                                                    <?php elseif($rental->transactionType == '3'): ?>
                                                    <td>
                                                        <span class="badge bg-label-danger">Sold</span>
                                                    </td>
                                                    <?php elseif($rental->transactionType == '4'): ?>
                                                    <td>
                                                        <span class="badge bg-label-danger">Stolen</span>
                                                    </td>
                                                    <?php elseif($rental->transactionType == '5'): ?>
                                                    <td>
                                                        <span class="badge bg-label-primary">Temp. Return</span>
                                                    </td>
                                                    <?php else: ?>
                                                    <td>
                                                        <span class="badge bg-label-primary"><?php echo e($rental->transactionType); ?></span>
                                                    </td>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($rental->transactionType === 'New Rental'): ?>
                                            <tr>
                                                <td>
                                                    <th>Rental Date</th>
                                                    <td><?php echo e(date('d-M-Y', strtotime($rental->rentalDay))); ?></td>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <tr>
                                                <td>
                                                    <th>Pre. Return Date</th>
                                                    <td><?php echo e(date('d-M-Y', strtotime($rental->rentalDay))); ?></td>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($rental->returnDate > 0): ?>
                                            <tr>
                                                <td>
                                                    <th>Return Date</th>
                                                    <td><?php echo e(date('d-M-Y', strtotime($rental->returnDate))); ?></td>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($rental->commingDate > 0): ?>
                                            <tr>
                                                <td>
                                                    <th>Coming Date</th>
                                                    <td><?php echo e(date('d-M-Y', strtotime($rental->commingDate))); ?></td>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($rental->rentalPeriod > 0): ?>
                                            <tr>
                                                <td>
                                                    <th>Rental Period</th>
                                                    <td><?php echo e($rental->rentalPeriod); ?> Days</td>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th class="bg-primary text-white fw-bold">Customer Informations</th>
                                <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="fw-bold">Name</th>
                                <th class="fw-bold">
                                    <a href="<?php echo e(route('customers.edit',$rental->customerID)); ?>"><?php echo e($rental->customer->CustomerName); ?></a>
                                </th>
                                    <td colspan="2">
                                        <?php if($rental->customer->nationality > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Nationality</th>
                                                <td><?php echo e($rental->customer->nationality); ?></td>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if($rental->customer->gender > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Gender</th>
                                                <td><?php echo e($rental->customer->gender); ?></td>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if($rental->contact != null): ?>
                                            <tr>
                                                <td>
                                                    <th>Contact</th>
                                                    <td>
                                                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($contact->is_Active == 1): ?>
                                                                <li>
                                                                    <?php echo e($contact->contactType); ?> : <?php echo e($contact->contactDetail); ?>

                                                                </li>
                                                            <?php else: ?>
                                                                <li>
                                                                    No Data
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($rental->deposit != null): ?>
                                            <tr>
                                                <td>
                                                    <th>Deposit</th>
                                                    <td>
                                                        <?php $__currentLoopData = $rental_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                            <?php if($rental_deposit->rentalID == $rental->rentalID): ?>
                                                                <?php if($rental_deposit->customerID == $rental->customerID): ?>
                                                                    <?php if($rental_deposit->currDepositType == 'Money'): ?>
                                                                        <li>
                                                                            <?php echo e($rental_deposit->currDepositType); ?> : $<?php echo e($rental_deposit->currDeposit); ?>

                                                                        </li>
                                                                    <?php else: ?>
                                                                        <li>
                                                                            <?php echo e($rental_deposit->currDepositType); ?> : <?php echo e($rental_deposit->currDeposit); ?>

                                                                        </li>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    No Data
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($rental->customer->address > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Address</th>
                                                <td><?php echo e($rental->customer->address); ?></td>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if($rental->customer->comment > 0): ?>
                                        <tr>
                                            <td>
                                                <th>Remark</th>
                                                <td><?php echo e($rental->customer->comment); ?></td>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if($rental->price > 0): ?>
                                        <tr>
                                            <td class="justify-content-center">
                                                <th>Price</th>
                                                <td><span class="badge bg-danger text-white ps-3 pe-3 pt-2 pb-2">$<?php echo e($rental->price); ?></span></td>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    

    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                    <h6 class="card-header bg-primary text-white">RENTAL LOGS</h6>
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                          <label class="col-lg-12 col-form-label">Filter</label>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Motorbike No.</span>
                                    <input name="motorno" class="form-control" list="motorno_list" id="motorno" value="<?php echo e(Request::get('motorno')); ?>" placeholder="Type to search...">
                                    <datalist id="motorno_list">
                                        <?php $__currentLoopData = $motorbike_no_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorbike->motorno); ?>"> <?php echo e($motorbike->motorno); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Rental Date</span>
                                    <input class="form-control" type="date" name="rentalDay" value="<?php echo e(Request::get('rentalDay')); ?>" id="rentalDay">
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Return Date</span>
                                    <input class="form-control" type="date" name="returnDate" value="<?php echo e(Request::get('returnDate')); ?>" id="returnDate">
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Status</span>
                                    <select class="form-select" name="transactionType" id="transactionType">
                                        <option value="">-- Status --</option>
                                        <?php $__currentLoopData = $rental_tran_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($motorbike->transactionType == 5): ?>
                                                <option value="5" <?php if(Request::get('transactionType') == 5): ?> selected <?php endif; ?>>Temp. Return</option>
                                            <?php elseif($motorbike->transactionType == 3): ?>
                                                <option value="3" <?php if(Request::get('transactionType') == 3): ?> selected <?php endif; ?>>Sold</option>
                                            <?php elseif($motorbike->transactionType == 4): ?>
                                                <option value="4" <?php if(Request::get('transactionType') == 4): ?> selected <?php endif; ?>>Stolen</option>
                                            <?php else: ?>
                                                <option value="<?php echo e($motorbike->transactionType); ?>" <?php if(Request::get('transactionType') == $motorbike->transactionType): ?> selected <?php endif; ?>><?php echo e($motorbike->transactionType); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Price</span>
                                    <input name="price" class="form-control" list="price_list" id="price" value="<?php echo e(Request::get('price')); ?>" placeholder="Type to search...">
                                    <datalist id="price_list">
                                        <?php $__currentLoopData = $rental_price_drop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorbike->price); ?>"> <?php echo e($motorbike->price); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="input-group">
                                    <button class="btn btn-warning">Search</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive text-nowrap">
                    <?php if(count($rental_logs) > 0): ?>
                    <table class="table table-hover table-bordered text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorID', 'Motor No.'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Deposit'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Status'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('rentalDay', 'Rental Date'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rental_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e($rental->motorInfor->motorno); ?> 
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $rental_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php if($rental_deposit->rentalID == $rental->rentalID): ?>
                                                <?php if($rental_deposit->customerID == $rental->customerID): ?>
                                                    <?php if($rental_deposit->currDepositType == 'Money'): ?>
                                                        <li>
                                                            <?php echo e($rental_deposit->currDepositType); ?> : $<?php echo e($rental_deposit->currDeposit); ?>

                                                        </li>
                                                    <?php else: ?>
                                                        <li>
                                                            <?php echo e($rental_deposit->currDepositType); ?> : <?php echo e($rental_deposit->currDeposit); ?>

                                                        </li>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    No Data
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($contact->contactType); ?> : <?php echo e($contact->contactDetail); ?>

                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    
                                    <?php if($rental->transactionType == 'New Rental'): ?>
                                        <td>
                                            <span class="badge bg-label-success"><?php echo e($rental->transactionType); ?></span>
                                        </td>
                                    <?php elseif($rental->transactionType == 'Extension'): ?>
                                    <td>
                                        <span class="badge bg-label-info"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                    <?php elseif($rental->transactionType == '5'): ?>
                                    <td>
                                        <span class="badge bg-label-primary">Temp. Return</span>
                                    </td>
                                    <?php elseif($rental->transactionType == 'Return'): ?>
                                    <td>
                                        <span class="badge bg-label-danger"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <span class="badge bg-label-primary"><?php echo e($rental->transactionType); ?></span>
                                    </td>
                                    <?php endif; ?>
                                    <td><?php echo e(date('d-M-Y', strtotime($rental->rentalDay))); ?></td>
                                    <td><?php echo e(date('d-M-Y', strtotime($rental->returnDate))); ?></td>
                                    <td>$<?php echo e($rental->price); ?></td>
                                    <td><?php echo e($rental->user->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <table class="table table-bordered text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('motorInfor.motorno', 'Motorbike No.'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.CustomerName', 'Customer Name'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('transactionType', 'Transaction Type'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('returnDate', 'Return Date'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', 'Price'));?>
                                </th>
                                <th>
                                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                </th>
                            </tr>
                        </thead>
                  </table><br/>
                  <p class="text-center">No transactions found.</p>
                <?php endif; ?>
                </div>
                <!-- Basic Pagination -->
                <div class="demo-inline-spacing">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <?php if($rental_logs->currentPage() > 1): ?>
                                    <li class="page-item first">
                                        <a href="/rentals/<?php echo e($rental->rentalID); ?>?page=<?php echo e($rental_logs->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                    </li>
                            <?php endif; ?>

                                    <?php for($i = 1; $i <= $rental_logs->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($rental_logs->currentPage() == $i ? 'active' : ''); ?>">
                                            <a class="page-link" href="/rentals/<?php echo e($rental->rentalID); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                <?php if($rental_logs->currentPage() < $rental_logs->lastPage()): ?>
                                    <li class="page-item last">
                                        <a href="/rentals/<?php echo e($rental->rentalID); ?>?page=<?php echo e($rental_logs->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                    </li>
                                <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <!--/ Basic Pagination -->
            </div>
         </div>
    </div>
    

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emcmotorbikerental.com/public_html/resources/views/content/rentals/show.blade.php ENDPATH**/ ?>