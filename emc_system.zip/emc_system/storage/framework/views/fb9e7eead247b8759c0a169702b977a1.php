

<?php $__env->startSection('title', 'Customers Information'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Home</a>
        <li class="breadcrumb-item active">Customers Information</li>
    </ol>
</nav>
<div class="row mb-3">
    <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-6 mb-3">
                <button type="button" class="btn btn-warning">
                    <a href="<?php echo e(route('export-customer')); ?>" style="color: white">Download Data</a>
                </button>
            </div>
            <div class="col-lg-6">
                <div class="d-flex justify-content-end gap-3">
                    <div>
                        <span class="badge bg-label-warning rounded-pill mt-1">Scooter: <?php echo e($scooter); ?></span>
                    </div>
                    <div>
                        <span class="badge bg-label-danger rounded-pill mt-1">Visa: <?php echo e($visa); ?></span>
                    </div>
                    <div>
                        <span class="badge bg-label-primary rounded-pill mt-1">Work Permit: <?php echo e($wp); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header bg-primary text-white">Customers Information</h5>

                
                <form action="" method="GET">
                    <div class="ms-3 me-3">
                        <div class="row">
                            <label class="col-form-label">Filter</label>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Customer Name</span>
                                    <input name="CustomerName" class="form-control" list="customer_name" id="CustomerName" value="<?php echo e(Request::get('CustomerName')); ?>" placeholder="Type to search...">
                                    <datalist id="customer_name">
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->CustomerName); ?>"> <?php echo e($customer->CustomerName); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Nationality</span>
                                    <input name="nationality" class="form-control" list="nationality_list" id="nationality" value="<?php echo e(Request::get('nationality')); ?>" placeholder="Type to search...">
                                    <datalist id="nationality_list">
                                        <?php $__currentLoopData = $countriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->nationality); ?>"> <?php echo e($country->nationality); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <span class="input-group-text">Address</span>
                                    <input name="address" class="form-control" id="address" value="<?php echo e(Request::get('address')); ?>" placeholder="Type to search...">
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <div class="input-group">
                                    <select class="form-select" name="gender" id="gender">
                                        <option value="">-- Select Gender --</option>
                                        <?php $__currentLoopData = $customer_gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gender->gender); ?>" <?php if(Request::get('gender') == $gender->gender): ?> selected <?php endif; ?>><?php echo e($gender->gender); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="input-group">
                                    <button class="btn btn-warning">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                
                <div class="ms-3 me-3">
                    
                    <?php echo $__env->make('layouts.sections.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <label class="col-form-label">Table Data</label>
                </div>
                <div class="table-responsive text-nowrap">
                    <?php if(count($customers) > 0): ?>
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customerID', 'No.'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('CustomerName', 'Customer Name'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('gender', 'Gender'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('nationality', 'Nationality'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Contact'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('address', 'Address'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('comment', 'comment'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                    </th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('customers.show', $customer->customerID)); ?>"><?php echo e($customer->customerID); ?></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('customers.show', $customer->customerID)); ?>"><?php echo e($customer->CustomerName); ?></a>
                                        </td>

                                        <?php if($customer->gender == null): ?>
                                            <td>No Data</td>
                                        <?php else: ?>
                                            <td><?php echo e($customer->gender); ?></td>
                                        <?php endif; ?>

                                        <?php if($customer->nationality == null): ?>
                                            <td>No Data</td>
                                        <?php else: ?>
                                            <td><?php echo e($customer->nationality); ?></td>
                                        <?php endif; ?>

                                        <td>
                                            <?php $__currentLoopData = $customer_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($customer_contact->customerID == $customer->customerID): ?>
                                                    <a href="<?php echo e(route('contacts.edit', $customer_contact->customerID)); ?>">
                                                        <li>
                                                            <?php echo e($customer_contact->contactType); ?> : <?php echo e($customer_contact->contactDetail); ?>

                                                        </li>
                                                    </a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>

                                        <?php if($customer->address != null): ?>
                                            <td><?php echo e($customer->address); ?></td>
                                        <?php else: ?>
                                            <td>No Data</td>
                                        <?php endif; ?>

                                        <?php if($customer->address == null): ?>
                                            <td>No Data</td>
                                        <?php else: ?>
                                            <td><?php echo e($customer->address); ?></td>
                                        <?php endif; ?>

                                        <td>
                                                <?php echo e($customer->user->name); ?>

                                        </td>
                                        <td class="text-center">
                                            <?php echo Form::open(['method' => 'get','route' => ['customers.edit', $customer->customerID],'style'=>'display:inline']); ?>

                                                <?php echo Form::submit('Edit', ['class' => 'btn btn-primary btn-xs']); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <table class="table table-bordered text-nowrap mb-3">
                            <thead>
                                <tr>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customerID', 'No.'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('CustomerName', 'Customer Name'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('gender', 'Gender'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('nationality', 'Nationality'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('address', 'Address'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('comment', 'comment'));?>
                                    </th>
                                    <th>
                                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('userID', 'Inputer'));?>
                                    </th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                        <p class="text-center">No customers found.</p>
                    <?php endif; ?>
                </div>
                <!-- Basic Pagination -->
                <div class="demo-inline-spacing">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-end">
                            <?php if($customers->currentPage() > 1): ?>
                                    <li class="page-item first">
                                        <a href="customers?page=<?php echo e($customers->currentPage() - 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-left"></i></a>
                                    </li>
                                <?php endif; ?>

                                    <?php for($i = 1; $i <= $customers->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($customers->currentPage() == $i ? 'active' : ''); ?>">
                                            <a class="page-link" href="customers?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                <?php if($customers->currentPage() < $customers->lastPage()): ?>
                                    <li class="page-item last">
                                        <a href="customers?page=<?php echo e($customers->currentPage() + 1); ?>" class="page-link"><i class="tf-icon bx bx-chevrons-right"></i></a>
                                    </li>
                                <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <!--/ Basic Pagination -->
            </div>
        </div>
    </div>
</div>

<script>
    window.onbeforeunload = function() {
    localStorage.setItem('scrollPos', document.documentElement.scrollTop);
    };

    window.onload = function() {
    var scrollPos = localStorage.getItem('scrollPos');
    if (scrollPos) {
        window.scrollTo(0, scrollPos);
    }
    };

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u944590381/domains/emccurrencyexchange.com/public_html/motorbike-rental/resources/views/content/customers/index.blade.php ENDPATH**/ ?>